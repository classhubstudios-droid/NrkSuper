"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to2, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to2, key) && key !== except)
        __defProp(to2, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to2;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/.pnpm/cuid@3.0.0/node_modules/cuid/lib/pad.js
var require_pad = __commonJS({
  "node_modules/.pnpm/cuid@3.0.0/node_modules/cuid/lib/pad.js"(exports, module2) {
    module2.exports = function pad(num, size) {
      var s2 = "000000000" + num;
      return s2.substr(s2.length - size);
    };
  }
});

// node_modules/.pnpm/cuid@3.0.0/node_modules/cuid/lib/fingerprint.browser.js
var require_fingerprint_browser = __commonJS({
  "node_modules/.pnpm/cuid@3.0.0/node_modules/cuid/lib/fingerprint.browser.js"(exports, module2) {
    var pad = require_pad();
    var env = typeof window === "object" ? window : self;
    var globalCount = Object.keys(env).length;
    var mimeTypesLength = navigator.mimeTypes ? navigator.mimeTypes.length : 0;
    var clientId = pad((mimeTypesLength + navigator.userAgent.length).toString(36) + globalCount.toString(36), 4);
    module2.exports = function fingerprint() {
      return clientId;
    };
  }
});

// node_modules/.pnpm/cuid@3.0.0/node_modules/cuid/lib/getRandomValue.browser.js
var require_getRandomValue_browser = __commonJS({
  "node_modules/.pnpm/cuid@3.0.0/node_modules/cuid/lib/getRandomValue.browser.js"(exports, module2) {
    var getRandomValue;
    var crypto2 = typeof window !== "undefined" && (window.crypto || window.msCrypto) || typeof self !== "undefined" && self.crypto;
    if (crypto2) {
      lim = Math.pow(2, 32) - 1;
      getRandomValue = function() {
        return Math.abs(crypto2.getRandomValues(new Uint32Array(1))[0] / lim);
      };
    } else {
      getRandomValue = Math.random;
    }
    var lim;
    module2.exports = getRandomValue;
  }
});

// node_modules/.pnpm/cuid@3.0.0/node_modules/cuid/index.js
var require_cuid = __commonJS({
  "node_modules/.pnpm/cuid@3.0.0/node_modules/cuid/index.js"(exports, module2) {
    var fingerprint = require_fingerprint_browser();
    var pad = require_pad();
    var getRandomValue = require_getRandomValue_browser();
    var c2 = 0;
    var blockSize = 4;
    var base = 36;
    var discreteValues = Math.pow(base, blockSize);
    function randomBlock() {
      return pad((getRandomValue() * discreteValues << 0).toString(base), blockSize);
    }
    function safeCounter() {
      c2 = c2 < discreteValues ? c2 : 0;
      c2++;
      return c2 - 1;
    }
    function cuid2() {
      var letter = "c", timestamp = (/* @__PURE__ */ new Date()).getTime().toString(base), counter = pad(safeCounter().toString(base), blockSize), print = fingerprint(), random = randomBlock() + randomBlock();
      return letter + timestamp + counter + print + random;
    }
    cuid2.slug = function slug() {
      var date = (/* @__PURE__ */ new Date()).getTime().toString(36), counter = safeCounter().toString(36).slice(-4), print = fingerprint().slice(0, 1) + fingerprint().slice(-1), random = randomBlock().slice(-2);
      return date.slice(-2) + counter + print + random;
    };
    cuid2.isCuid = function isCuid(stringToCheck) {
      if (typeof stringToCheck !== "string") return false;
      if (stringToCheck.startsWith("c")) return true;
      return false;
    };
    cuid2.isSlug = function isSlug(stringToCheck) {
      if (typeof stringToCheck !== "string") return false;
      var stringLength = stringToCheck.length;
      if (stringLength >= 7 && stringLength <= 10) return true;
      return false;
    };
    cuid2.fingerprint = fingerprint;
    module2.exports = cuid2;
  }
});

// node_modules/.pnpm/@nrk+debug@1.1.0/node_modules/@nrk/debug/debug.js
var COLORS = [
  "#0000CC",
  "#0000FF",
  "#0033CC",
  "#0033FF",
  "#0066CC",
  "#0066FF",
  "#0099CC",
  "#0099FF",
  "#00CC00",
  "#00CC33",
  "#00CC66",
  "#00CC99",
  "#00CCCC",
  "#00CCFF",
  "#3300CC",
  "#3300FF",
  "#3333CC",
  "#3333FF",
  "#3366CC",
  "#3366FF",
  "#3399CC",
  "#3399FF",
  "#33CC00",
  "#33CC33",
  "#33CC66",
  "#33CC99",
  "#33CCCC",
  "#33CCFF",
  "#6600CC",
  "#6600FF",
  "#6633CC",
  "#6633FF",
  "#66CC00",
  "#66CC33",
  "#9900CC",
  "#9900FF",
  "#9933CC",
  "#9933FF",
  "#99CC00",
  "#99CC33",
  "#CC0000",
  "#CC0033",
  "#CC0066",
  "#CC0099",
  "#CC00CC",
  "#CC00FF",
  "#CC3300",
  "#CC3333",
  "#CC3366",
  "#CC3399",
  "#CC33CC",
  "#CC33FF",
  "#CC6600",
  "#CC6633",
  "#CC9900",
  "#CC9933",
  "#CCCC00",
  "#CCCC33",
  "#FF0000",
  "#FF0033",
  "#FF0066",
  "#FF0099",
  "#FF00CC",
  "#FF00FF",
  "#FF3300",
  "#FF3333",
  "#FF3366",
  "#FF3399",
  "#FF33CC",
  "#FF33FF",
  "#FF6600",
  "#FF6633",
  "#FF9900",
  "#FF9933",
  "#FFCC00",
  "#FFCC33"
];
var namespaces = /* @__PURE__ */ new Set();
function debugFactory(namespace) {
  if (/\s/.test(namespace)) {
    throw Error("debug namespaces cannot include whitespace");
  }
  namespaces.add(namespace);
  if (!isEnabled(namespace)) {
    return function debug4() {
    };
  }
  const color = selectColor(namespace);
  let lastCalled = 0;
  return function debug4(...data) {
    const now = Date.now();
    const diff = now - (lastCalled || now);
    debugFactory.logFn(`%c${namespace} +${diff}ms`, `color: ${color}`, ...data);
    lastCalled = now;
  };
}
debugFactory.logFn = console.log.bind(console);
function isEnabled(namespace) {
  try {
    const patterns = (localStorage.getItem("debug") || "").replace(/^["']/, "").replace(/["']$/, "").split(/[\s,]+/g);
    for (const pattern of patterns) {
      if (pattern === "") {
        continue;
      }
      const wildcardIdx = pattern.indexOf("*");
      if (wildcardIdx > -1) {
        if (namespace.startsWith(pattern.slice(0, wildcardIdx))) {
          return true;
        }
      } else {
        if (namespace === pattern) {
          return true;
        }
      }
    }
  } catch (_) {
  }
  return false;
}
function selectColor(namespace) {
  let hash = 0;
  for (let i2 = 0; i2 < namespace.length; i2++) {
    hash = (hash << 5) - hash + namespace.charCodeAt(i2);
    hash |= 0;
  }
  return COLORS[Math.abs(hash) % COLORS.length];
}

// node_modules/.pnpm/@nrk+snowplow-web@4.2.5_@snowplow+browser-tracker@4.6.3_@snowplow+tracker-core@4.6.3/node_modules/@nrk/snowplow-web/index.js
var import_cuid = __toESM(require_cuid(), 1);
var __defProp2 = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp2 = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp2(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a2, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp2.call(b, prop))
      __defNormalProp(a2, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a2, prop, b[prop]);
    }
  return a2;
};
var __spreadProps = (a2, b) => __defProps(a2, __getOwnPropDescs(b));
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var ClickEventKind = /* @__PURE__ */ ((ClickEventKind2) => {
  ClickEventKind2["Content"] = "content";
  ClickEventKind2["Other"] = "other";
  return ClickEventKind2;
})(ClickEventKind || {});
var ImpressionEventKind = /* @__PURE__ */ ((ImpressionEventKind2) => {
  ImpressionEventKind2["Impression"] = "impression";
  return ImpressionEventKind2;
})(ImpressionEventKind || {});
var EventSchema = /* @__PURE__ */ ((EventSchema2) => {
  EventSchema2["BackstageEvent"] = "iglu:no.nrk.innlogging/backstage-event/jsonschema/1-0-0";
  EventSchema2["BridgeEvent"] = "iglu:no.nrk/bridge-event/jsonschema/1-0-0";
  EventSchema2["ClickEvent"] = "iglu:no.nrk/click-event/jsonschema/1-0-0";
  EventSchema2["FavouriteEvent"] = "iglu:no.nrk/favourite-event/jsonschema/1-0-0";
  EventSchema2["FrontstageServerEvent"] = "iglu:no.nrk.innlogging/frontstage-server-event/jsonschema/1-0-0";
  EventSchema2["ImpressionEvent"] = "iglu:no.nrk/impression-event/jsonschema/1-0-0";
  EventSchema2["LoginRegisterFlowEvent"] = "iglu:no.nrk.innlogging/login-register-flow-event/jsonschema/1-0-0";
  EventSchema2["NotificationEvent"] = "iglu:no.nrk/notification-event/jsonschema/1-0-0";
  EventSchema2["PlaybackEvent"] = "iglu:no.nrk/playback-event/jsonschema/1-0-0";
  EventSchema2["ProfilePageEvent"] = "iglu:no.nrk.innlogging/profile-page-event/jsonschema/1-0-0";
  EventSchema2["RadioEvent"] = "iglu:no.nrk.radio/radio-event/jsonschema/1-0-0";
  EventSchema2["SearchEvent"] = "iglu:no.nrk/search-event/jsonschema/1-0-0";
  EventSchema2["StepEvent"] = "iglu:no.nrk.dh/step-event/jsonschema/1-0-0";
  EventSchema2["TimeSpentEvent"] = "iglu:no.nrk/time-spent-event/jsonschema/1-0-0";
  EventSchema2["ViewportEvent"] = "iglu:no.nrk.dh/viewport-event/jsonschema/1-0-0";
  return EventSchema2;
})(EventSchema || {});
var EntitySchema = /* @__PURE__ */ ((EntitySchema2) => {
  EntitySchema2["Bridge"] = "iglu:no.nrk/bridge/jsonschema/1-0-0";
  EntitySchema2["ClientID"] = "iglu:no.nrk.innlogging/client-id/jsonschema/1-0-0";
  EntitySchema2["Content"] = "iglu:no.nrk/content/jsonschema/1-0-1";
  EntitySchema2["Experiment"] = "iglu:no.nrk/experiment/jsonschema/1-0-0";
  EntitySchema2["Link"] = "iglu:no.nrk/link/jsonschema/2-0-0";
  EntitySchema2["NrkSession"] = "iglu:no.nrk/nrk-session/jsonschema/1-0-0";
  EntitySchema2["NrkUser"] = "iglu:no.nrk/nrk-user/jsonschema/1-0-0";
  EntitySchema2["Plug"] = "iglu:no.nrk/plug/jsonschema/3-0-1";
  EntitySchema2["PreviousWebPage"] = "iglu:no.nrk/previous-web-page/jsonschema/1-0-0";
  EntitySchema2["RegistrationContext"] = "iglu:no.nrk.innlogging/registration-context/jsonschema/1-0-0";
  EntitySchema2["SearchResult"] = "iglu:no.nrk/search-result/jsonschema/1-0-1";
  EntitySchema2["Service"] = "iglu:no.nrk/service/jsonschema/2-0-0";
  EntitySchema2["Application"] = "iglu:com.snowplowanalytics.mobile/application/jsonschema/1-0-0";
  EntitySchema2["DesktopContext"] = "iglu:com.snowplowanalytics.snowplow/desktop_context/jsonschema/1-0-0";
  return EntitySchema2;
})(EntitySchema || {});
var debug = debugFactory("app:snowplow:tracker");
var _sharedEntities;
var NrkBaseTracker = class {
  constructor(snowplow, config) {
    __privateAdd(this, _sharedEntities, {});
    var _a, _b, _c;
    this.snowplow = snowplow;
    this.trackerId = (_a = config.trackerId) != null ? _a : import_cuid.default.slug();
    debug(`Setting shared entity ${"iglu:no.nrk/service/jsonschema/2-0-0"} with id ${config.serviceId}`);
    this.setSharedEntity("iglu:no.nrk/service/jsonschema/2-0-0", { id: config.serviceId, environment: (_b = config.environment) != null ? _b : null });
    if (config.osType && config.osVersion) {
      debug(
        `Setting shared entity ${"iglu:com.snowplowanalytics.snowplow/desktop_context/jsonschema/1-0-0"} with osType = ${config.osType} and osVersion = ${config.osVersion}`
      );
      this.setSharedEntity("iglu:com.snowplowanalytics.snowplow/desktop_context/jsonschema/1-0-0", { osType: config.osType, osVersion: config.osVersion });
    }
    if (config.appVersion && config.appBuild) {
      debug(
        `Setting shared entity ${"iglu:com.snowplowanalytics.mobile/application/jsonschema/1-0-0"} with build ${config.appBuild} and version ${config.appVersion}`
      );
      this.setSharedEntity("iglu:com.snowplowanalytics.mobile/application/jsonschema/1-0-0", { build: config.appBuild, version: config.appVersion });
    }
    debug(`Creating tracker with ID ${this.trackerId}, web context: ${!config.disableWebContext}`);
    snowplow.newTracker(this.trackerId, config.collectorUrl, {
      postPath: "/nrk/wd6",
      appId: config.appId,
      plugins: config.plugins,
      platform: (_c = config.platform) != null ? _c : "web",
      discoverRootDomain: false,
      contexts: {
        webPage: config.disableWebContext !== true
      },
      stateStorageStrategy: config.disableLocalStorage ? "cookie" : void 0
    });
  }
  /**
   * Track page view.
   */
  trackPageView(contentEntity) {
    if (contentEntity) {
      debug(`Tracking page view with entity ${contentEntity.kind}/${contentEntity.id} (tracker: ${this.trackerId})`);
      this.snowplow.trackPageView(
        {
          context: entitiesToContexts(__spreadProps(__spreadValues({}, __privateGet(this, _sharedEntities)), {
            [
              "iglu:no.nrk/content/jsonschema/1-0-1"
              /* Content */
            ]: contentEntity
          }))
        },
        [this.trackerId]
      );
    } else {
      debug(`Tracking page view without contentEntity (tracker: ${this.trackerId})`);
      this.snowplow.trackPageView({ context: entitiesToContexts(__privateGet(this, _sharedEntities)) }, [this.trackerId]);
    }
  }
  /**
   * Generic track event for custom schemas, typed up to only support NRK
   * events and entities. All shared entities are included, and can be
   * overridden by specified entities.
   */
  trackSchemaEvent(schema, data, entities) {
    const context = entitiesToContexts(__spreadValues(__spreadValues({}, __privateGet(this, _sharedEntities)), entities));
    debug(`Tracking event with schema ${schema} and data ${JSON.stringify(data)} (tracker: ${this.trackerId})`);
    const eventData = data;
    this.snowplow.trackSelfDescribingEvent(
      {
        event: { schema, data: eventData },
        context
      },
      [this.trackerId]
    );
  }
  /**
   * Send a standard structured event.
   */
  trackEvent(data, entities) {
    const context = entitiesToContexts(__spreadValues(__spreadValues({}, __privateGet(this, _sharedEntities)), entities));
    debug(`Tracking structured event width enitites ${entities} (tracker: ${this.trackerId})`);
    this.snowplow.trackStructEvent(__spreadProps(__spreadValues({}, data), { context }), [this.trackerId]);
  }
  /**
   * Set the logged in user.
   */
  setUser(userId) {
    this.snowplow.setUserId(userId, [this.trackerId]);
    debug(`Setting shared entity ${"iglu:no.nrk/nrk-user/jsonschema/1-0-0"} with id ${userId}`);
    this.setSharedEntity("iglu:no.nrk/nrk-user/jsonschema/1-0-0", { id: userId });
  }
  /**
   * Clear the user when logged out.
   */
  clearUser() {
    this.snowplow.setUserId(null, [this.trackerId]);
    debug(`Removing shared entity ${"iglu:no.nrk/nrk-user/jsonschema/1-0-0"}`);
    this.removeSharedEntity(
      "iglu:no.nrk/nrk-user/jsonschema/1-0-0"
      /* NrkUser */
    );
  }
  /**
   * Add a plugin to the tracker.
   */
  addPlugin(configuration) {
    this.snowplow.addPlugin(configuration, [this.trackerId]);
  }
  /**
   * Set data for a shared entity for all events of this tracker.
   *
   * The `snowplow.addGlobalContexts()` method could potentially be used, but
   * `removeGlobalContexts()` requires the data as argument as well (awkward),
   * and there's no `getGlobalContexts()` to help with that.
   */
  setSharedEntity(schema, data) {
    __privateGet(this, _sharedEntities)[schema] = data;
  }
  /**
   * Returns any shared entities for an entity schema.
   */
  getSharedEntity(schema) {
    return __privateGet(this, _sharedEntities)[schema];
  }
  /**
   * Remove all shared entities for an entity schema.
   */
  removeSharedEntity(schema) {
    if (schema in __privateGet(this, _sharedEntities)) {
      delete __privateGet(this, _sharedEntities)[schema];
    }
  }
};
_sharedEntities = /* @__PURE__ */ new WeakMap();
function entitiesToContexts(entities) {
  const contexts = [];
  for (const [schema, data] of Object.entries(entities)) {
    const dataList = Array.isArray(data) ? data : [data];
    for (const entityData of dataList) {
      contexts.push({ schema, data: __spreadValues({}, entityData) });
    }
  }
  return contexts;
}
var _channelId;
var _autoplay;
_channelId = /* @__PURE__ */ new WeakMap();
_autoplay = /* @__PURE__ */ new WeakMap();
var ServiceID = /* @__PURE__ */ ((ServiceID2) => {
  ServiceID2["Embed"] = "embed";
  ServiceID2["Nrkbeta"] = "nrkbeta";
  ServiceID2["Nrkinnlogging"] = "nrkinnlogging";
  ServiceID2["Nrkno"] = "nrkno";
  ServiceID2["Nrkp3"] = "nrkp3";
  ServiceID2["Nrkradio"] = "nrkradio";
  ServiceID2["Nrksuper"] = "nrksuper";
  ServiceID2["Nrktv"] = "nrktv";
  ServiceID2["Yr"] = "yr";
  return ServiceID2;
})(ServiceID || {});
var debug2 = debugFactory("app:snowplow:tracker");

// node_modules/.pnpm/@nrk+snowplow-web@4.2.5_@snowplow+browser-tracker@4.6.3_@snowplow+tracker-core@4.6.3/node_modules/@nrk/snowplow-web/plugins/previous-web-page-context-plugin.js
var i = "nrk-sp-keep-session-alive";
var o = (r) => r.getPayload().e === "pv";
var s = "nrksppwp";
var g = 30 * 60;
var a = class {
  constructor(e) {
    var t;
    this.sessionDuration = (t = e == null ? void 0 : e.sessionDuration) != null ? t : g, window.addEventListener("message", (n) => {
      n.data === i && this.touchPreviousPageViewId();
    });
  }
  activateBrowserPlugin(e) {
    this.tracker = e;
  }
  logger(e) {
    this.log = e;
  }
  beforeTrack(e) {
    if (o(e)) {
      let t = this.tracker.getPageViewId(), n = this.fetchPreviousPageViewId();
      n !== void 0 && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(n) && e.addContextEntity({ schema: "iglu:no.nrk/previous-web-page/jsonschema/1-0-0", data: { id: n } }), this.storePreviousPageViewId(t);
    } else this.touchPreviousPageViewId();
  }
  fetchPreviousPageViewId() {
    var t;
    let e;
    try {
      let n = window.localStorage.getItem(s);
      n && (e = JSON.parse(n));
    } catch (n) {
      (t = this.log) == null || t.warn("Failed to fetch previous page view ID:", n);
    }
    if (typeof e == "object" && e !== null && typeof e.t == "number" && Date.now() - e.t <= this.sessionDuration * 1e3) return e.v;
  }
  storePreviousPageViewId(e) {
    var t;
    try {
      window.localStorage.setItem(s, JSON.stringify({ t: Date.now(), v: e }));
    } catch (n) {
      (t = this.log) == null || t.warn("Failed to store previous page view ID:", n);
    }
  }
  touchPreviousPageViewId() {
    let e = this.fetchPreviousPageViewId();
    e !== void 0 && this.storePreviousPageViewId(e);
  }
};

// node_modules/.pnpm/@nrk+snowplow-web@4.2.5_@snowplow+browser-tracker@4.6.3_@snowplow+tracker-core@4.6.3/node_modules/@nrk/snowplow-web/plugins/shared-web-page-context-plugin.js
var p = ["#0000CC", "#0000FF", "#0033CC", "#0033FF", "#0066CC", "#0066FF", "#0099CC", "#0099FF", "#00CC00", "#00CC33", "#00CC66", "#00CC99", "#00CCCC", "#00CCFF", "#3300CC", "#3300FF", "#3333CC", "#3333FF", "#3366CC", "#3366FF", "#3399CC", "#3399FF", "#33CC00", "#33CC33", "#33CC66", "#33CC99", "#33CCCC", "#33CCFF", "#6600CC", "#6600FF", "#6633CC", "#6633FF", "#66CC00", "#66CC33", "#9900CC", "#9900FF", "#9933CC", "#9933FF", "#99CC00", "#99CC33", "#CC0000", "#CC0033", "#CC0066", "#CC0099", "#CC00CC", "#CC00FF", "#CC3300", "#CC3333", "#CC3366", "#CC3399", "#CC33CC", "#CC33FF", "#CC6600", "#CC6633", "#CC9900", "#CC9933", "#CCCC00", "#CCCC33", "#FF0000", "#FF0033", "#FF0066", "#FF0099", "#FF00CC", "#FF00FF", "#FF3300", "#FF3333", "#FF3366", "#FF3399", "#FF33CC", "#FF33FF", "#FF6600", "#FF6633", "#FF9900", "#FF9933", "#FFCC00", "#FFCC33"];
var V = /* @__PURE__ */ new Set();
function d(s2) {
  if (/\s/.test(s2)) throw Error("debug namespaces cannot include whitespace");
  if (V.add(s2), !P(s2)) return function() {
  };
  let e = k(s2), i2 = 0;
  return function(...n) {
    let r = Date.now(), a2 = r - (i2 || r);
    d.logFn(`%c${s2} +${a2}ms`, `color: ${e}`, ...n), i2 = r;
  };
}
d.logFn = console.log.bind(console);
function P(s2) {
  try {
    let e = (localStorage.getItem("debug") || "").replace(/^["']/, "").replace(/["']$/, "").split(/[\s,]+/g);
    for (let i2 of e) {
      if (i2 === "") continue;
      let t = i2.indexOf("*");
      if (t > -1) {
        if (s2.startsWith(i2.slice(0, t))) return true;
      } else if (s2 === i2) return true;
    }
  } catch (e) {
  }
  return false;
}
function k(s2) {
  let e = 0;
  for (let i2 = 0; i2 < s2.length; i2++) e = (e << 5) - e + s2.charCodeAt(i2), e |= 0;
  return p[Math.abs(e) % p.length];
}
var u = "nrk-sp-keep-session-alive";
var c = "iglu:com.snowplowanalytics.snowplow/web_page/jsonschema/1-0-0";
var h = (s2) => s2.getPayload().e === "pv";
function l(s2) {
  var n, r;
  let e = s2.getJson().find((a2) => a2.keyIfEncoded === "cx"), i2 = (n = e == null ? void 0 : e.json) == null ? void 0 : n.data, t = i2 == null ? void 0 : i2.find((a2) => a2.schema === c);
  return (r = t == null ? void 0 : t.data) == null ? void 0 : r.id;
}
var C = "SharedWebPageContextPlugin";
var f = "requestPageViewId";
var I = "sharePageViewId";
var S = /(:\/\/|\.)((nrk|nrksuper|nrkbeta|p3|yr)\.no|nrk\.cloud)$/;
var o2 = d("app:snowplow:shared-web-page-context-plugin");
var F = class {
  constructor() {
    this.origin = window.location.origin;
    this.otherWindows = [];
    this.sequence = -1;
    window.addEventListener("message", (e) => {
      var i2, t, n, r;
      !["", "/", this.origin].includes(e.origin) && !S.test(e.origin) || e.source !== null && !("self" in e.source) || (v(e) ? (o2(`onMessage: Received page view ID ${e.data.pageViewId}, storing in plugin. tracker: ${JSON.stringify({ id: (i2 = this.tracker) == null ? void 0 : i2.id, pageViewId: (t = this.tracker) == null ? void 0 : t.getPageViewId() })}`), this.setPageViewId(e.data.pageViewId, e.data.sequence)) : M(e) && (e.source !== null && e.source !== window && this.otherWindows.push({ source: e.source, origin: e.origin }), this.pageViewId !== void 0 && (o2(`onMessage: Sending page view ID ${this.pageViewId} to other instances in window. tracker: ${JSON.stringify({ id: (n = this.tracker) == null ? void 0 : n.id, pageViewId: (r = this.tracker) == null ? void 0 : r.getPageViewId() })}`), this.sendPageViewId(e.source, e.origin, this.pageViewId, this.sequence))));
    }), this.sendRequest(window.parent, "*");
  }
  get pageViewId() {
    return this.__pageViewId;
  }
  activateBrowserPlugin(e) {
    this.tracker = e;
  }
  beforeTrack(e) {
    var t, n, r, a2, w;
    let i2 = l(e);
    if (h(e)) {
      let g2 = i2;
      g2 === void 0 && (g2 = (t = this.tracker) == null ? void 0 : t.getPageViewId()), o2(`beforetrack: Received new page view ID ${g2}, storing in plugin. tracker: ${JSON.stringify({ id: (n = this.tracker) == null ? void 0 : n.id, pageViewId: (r = this.tracker) == null ? void 0 : r.getPageViewId() })}`), this.setPageViewId(g2, this.sequence + 1), this.pageViewId !== void 0 && (o2(`beforetrack: Sending page view ID ${this.pageViewId} to other instances in window. tracker: ${JSON.stringify({ id: (a2 = this.tracker) == null ? void 0 : a2.id, pageViewId: (w = this.tracker) == null ? void 0 : w.getPageViewId() })}`), this.sendPageViewId(window, this.origin, this.pageViewId, this.sequence));
    }
    o2(`beforetrack: Event is not pageview. Existing page view ID:${this.pageViewId}. event pageViewId:${i2}`), i2 === void 0 && this.pageViewId !== void 0 && e.addContextEntity({ schema: c, data: { id: this.pageViewId } }), window.parent.postMessage(u, "*");
  }
  setPageViewId(e, i2) {
    var t;
    e !== void 0 && this.__pageViewId !== e && this.sequence < i2 && (o2(`update page view ID ${this.__pageViewId} -> ${e}. tracker: ${(t = this.tracker) == null ? void 0 : t.id} ${this.sequence} < ${i2}`), this.__pageViewId = e, this.sequence = i2, this.shareWithOtherWindows(e, i2));
  }
  shareWithOtherWindows(e, i2) {
    var t, n;
    for (let r of this.otherWindows) o2(`Sharing page view ID ${this.pageViewId} with other windows. tracker: ${JSON.stringify({ id: (t = this.tracker) == null ? void 0 : t.id, pageViewId: (n = this.tracker) == null ? void 0 : n.getPageViewId() })}`), this.sendPageViewId(r.source, r.origin, e, i2);
  }
  sendRequest(e, i2) {
    this.sendMessage(e, i2, { namespace: C, topic: f });
  }
  sendPageViewId(e, i2, t, n) {
    this.sendMessage(e, i2, { namespace: C, topic: I, pageViewId: t, sequence: n });
  }
  sendMessage(e, i2, t) {
    e === null || i2 === "" || i2 === "/" ? window.postMessage(t, this.origin) : e.postMessage(t, i2);
  }
};
var E = (s2) => {
  let e = s2.data;
  return typeof e == "object" && e !== null && e.namespace === C;
};
var M = (s2) => E(s2) && s2.data.topic === f;
var v = (s2) => E(s2) && s2.data.topic === I;

// node_modules/.pnpm/@nrk+snowplow-web@4.2.5_@snowplow+browser-tracker@4.6.3_@snowplow+tracker-core@4.6.3/node_modules/@nrk/snowplow-web/snowplow-bundle.js
var snowplow_bundle_exports = {};
__export(snowplow_bundle_exports, {
  addPlugin: () => xi,
  newTracker: () => Ii,
  preservePageViewId: () => Si,
  setUserId: () => hi,
  trackPageView: () => yi,
  trackSelfDescribingEvent: () => bi,
  trackStructEvent: () => wi
});
var Jr = Object.create;
var Dn = Object.defineProperty;
var Wr = Object.getOwnPropertyDescriptor;
var Xr = Object.getOwnPropertyNames;
var Yr = Object.getPrototypeOf;
var Qr = Object.prototype.hasOwnProperty;
var Lt = (e, t) => () => (t || e((t = { exports: {} }).exports, t), t.exports);
var Zr = (e, t, n, r) => {
  if (t && typeof t == "object" || typeof t == "function") for (let o3 of Xr(t)) !Qr.call(e, o3) && o3 !== n && Dn(e, o3, { get: () => t[o3], enumerable: !(r = Wr(t, o3)) || r.enumerable });
  return e;
};
var $r = (e, t, n) => (n = e != null ? Jr(Yr(e)) : {}, Zr(t || !e || !e.__esModule ? Dn(n, "default", { value: e, enumerable: true }) : n, e));
var tr = Lt((Ni, er) => {
  (function() {
    var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", t = { rotl: function(n, r) {
      return n << r | n >>> 32 - r;
    }, rotr: function(n, r) {
      return n << 32 - r | n >>> r;
    }, endian: function(n) {
      if (n.constructor == Number) return t.rotl(n, 8) & 16711935 | t.rotl(n, 24) & 4278255360;
      for (var r = 0; r < n.length; r++) n[r] = t.endian(n[r]);
      return n;
    }, randomBytes: function(n) {
      for (var r = []; n > 0; n--) r.push(Math.floor(Math.random() * 256));
      return r;
    }, bytesToWords: function(n) {
      for (var r = [], o3 = 0, a2 = 0; o3 < n.length; o3++, a2 += 8) r[a2 >>> 5] |= n[o3] << 24 - a2 % 32;
      return r;
    }, wordsToBytes: function(n) {
      for (var r = [], o3 = 0; o3 < n.length * 32; o3 += 8) r.push(n[o3 >>> 5] >>> 24 - o3 % 32 & 255);
      return r;
    }, bytesToHex: function(n) {
      for (var r = [], o3 = 0; o3 < n.length; o3++) r.push((n[o3] >>> 4).toString(16)), r.push((n[o3] & 15).toString(16));
      return r.join("");
    }, hexToBytes: function(n) {
      for (var r = [], o3 = 0; o3 < n.length; o3 += 2) r.push(parseInt(n.substr(o3, 2), 16));
      return r;
    }, bytesToBase64: function(n) {
      for (var r = [], o3 = 0; o3 < n.length; o3 += 3) for (var a2 = n[o3] << 16 | n[o3 + 1] << 8 | n[o3 + 2], u2 = 0; u2 < 4; u2++) o3 * 8 + u2 * 6 <= n.length * 8 ? r.push(e.charAt(a2 >>> 6 * (3 - u2) & 63)) : r.push("=");
      return r.join("");
    }, base64ToBytes: function(n) {
      n = n.replace(/[^A-Z0-9+\/]/ig, "");
      for (var r = [], o3 = 0, a2 = 0; o3 < n.length; a2 = ++o3 % 4) a2 != 0 && r.push((e.indexOf(n.charAt(o3 - 1)) & Math.pow(2, -2 * a2 + 8) - 1) << a2 * 2 | e.indexOf(n.charAt(o3)) >>> 6 - a2 * 2);
      return r;
    } };
    er.exports = t;
  })();
});
var Wt = Lt((zi, nr) => {
  var Jt = { utf8: { stringToBytes: function(e) {
    return Jt.bin.stringToBytes(unescape(encodeURIComponent(e)));
  }, bytesToString: function(e) {
    return decodeURIComponent(escape(Jt.bin.bytesToString(e)));
  } }, bin: { stringToBytes: function(e) {
    for (var t = [], n = 0; n < e.length; n++) t.push(e.charCodeAt(n) & 255);
    return t;
  }, bytesToString: function(e) {
    for (var t = [], n = 0; n < e.length; n++) t.push(String.fromCharCode(e[n]));
    return t.join("");
  } } };
  nr.exports = Jt;
});
var or = Lt((Bi, rr) => {
  (function() {
    var e = tr(), t = Wt().utf8, n = Wt().bin, r = function(a2) {
      a2.constructor == String ? a2 = t.stringToBytes(a2) : typeof Buffer != "undefined" && typeof Buffer.isBuffer == "function" && Buffer.isBuffer(a2) ? a2 = Array.prototype.slice.call(a2, 0) : Array.isArray(a2) || (a2 = a2.toString());
      var u2 = e.bytesToWords(a2), c2 = a2.length * 8, f2 = [], s2 = 1732584193, l2 = -271733879, v2 = -1732584194, m = 271733878, y = -1009589776;
      u2[c2 >> 5] |= 128 << 24 - c2 % 32, u2[(c2 + 64 >>> 9 << 4) + 15] = c2;
      for (var w = 0; w < u2.length; w += 16) {
        for (var g2 = s2, P2 = l2, q = v2, Q = m, S2 = y, I2 = 0; I2 < 80; I2++) {
          if (I2 < 16) f2[I2] = u2[w + I2];
          else {
            var p2 = f2[I2 - 3] ^ f2[I2 - 8] ^ f2[I2 - 14] ^ f2[I2 - 16];
            f2[I2] = p2 << 1 | p2 >>> 31;
          }
          var T = (s2 << 5 | s2 >>> 27) + y + (f2[I2] >>> 0) + (I2 < 20 ? (l2 & v2 | ~l2 & m) + 1518500249 : I2 < 40 ? (l2 ^ v2 ^ m) + 1859775393 : I2 < 60 ? (l2 & v2 | l2 & m | v2 & m) - 1894007588 : (l2 ^ v2 ^ m) - 899497514);
          y = m, m = v2, v2 = l2 << 30 | l2 >>> 2, l2 = s2, s2 = T;
        }
        s2 += g2, l2 += P2, v2 += q, m += Q, y += S2;
      }
      return [s2, l2, v2, m, y];
    }, o3 = function(a2, u2) {
      var c2 = e.wordsToBytes(r(a2));
      return u2 && u2.asBytes ? c2 : u2 && u2.asString ? n.bytesToString(c2) : e.bytesToHex(c2);
    };
    o3._blocksize = 16, o3._digestsize = 20, rr.exports = o3;
  })();
});
var V2 = function() {
  return V2 = Object.assign || function(t) {
    for (var n, r = 1, o3 = arguments.length; r < o3; r++) {
      n = arguments[r];
      for (var a2 in n) Object.prototype.hasOwnProperty.call(n, a2) && (t[a2] = n[a2]);
    }
    return t;
  }, V2.apply(this, arguments);
};
function ze(e, t, n, r) {
  function o3(a2) {
    return a2 instanceof n ? a2 : new n(function(u2) {
      u2(a2);
    });
  }
  return new (n || (n = Promise))(function(a2, u2) {
    function c2(l2) {
      try {
        s2(r.next(l2));
      } catch (v2) {
        u2(v2);
      }
    }
    function f2(l2) {
      try {
        s2(r.throw(l2));
      } catch (v2) {
        u2(v2);
      }
    }
    function s2(l2) {
      l2.done ? a2(l2.value) : o3(l2.value).then(c2, f2);
    }
    s2((r = r.apply(e, t || [])).next());
  });
}
function Be(e, t) {
  var n = { label: 0, sent: function() {
    if (a2[0] & 1) throw a2[1];
    return a2[1];
  }, trys: [], ops: [] }, r, o3, a2, u2 = Object.create((typeof Iterator == "function" ? Iterator : Object).prototype);
  return u2.next = c2(0), u2.throw = c2(1), u2.return = c2(2), typeof Symbol == "function" && (u2[Symbol.iterator] = function() {
    return this;
  }), u2;
  function c2(s2) {
    return function(l2) {
      return f2([s2, l2]);
    };
  }
  function f2(s2) {
    if (r) throw new TypeError("Generator is already executing.");
    for (; u2 && (u2 = 0, s2[0] && (n = 0)), n; ) try {
      if (r = 1, o3 && (a2 = s2[0] & 2 ? o3.return : s2[0] ? o3.throw || ((a2 = o3.return) && a2.call(o3), 0) : o3.next) && !(a2 = a2.call(o3, s2[1])).done) return a2;
      switch (o3 = 0, a2 && (s2 = [s2[0] & 2, a2.value]), s2[0]) {
        case 0:
        case 1:
          a2 = s2;
          break;
        case 4:
          return n.label++, { value: s2[1], done: false };
        case 5:
          n.label++, o3 = s2[1], s2 = [0];
          continue;
        case 7:
          s2 = n.ops.pop(), n.trys.pop();
          continue;
        default:
          if (a2 = n.trys, !(a2 = a2.length > 0 && a2[a2.length - 1]) && (s2[0] === 6 || s2[0] === 2)) {
            n = 0;
            continue;
          }
          if (s2[0] === 3 && (!a2 || s2[1] > a2[0] && s2[1] < a2[3])) {
            n.label = s2[1];
            break;
          }
          if (s2[0] === 6 && n.label < a2[1]) {
            n.label = a2[1], a2 = s2;
            break;
          }
          if (a2 && n.label < a2[2]) {
            n.label = a2[2], n.ops.push(s2);
            break;
          }
          a2[2] && n.ops.pop(), n.trys.pop();
          continue;
      }
      s2 = t.call(e, n);
    } catch (l2) {
      s2 = [6, l2], o3 = 0;
    } finally {
      r = a2 = 0;
    }
    if (s2[0] & 5) throw s2[1];
    return { value: s2[0] ? s2[1] : void 0, done: true };
  }
}
function W(e, t, n) {
  if (n || arguments.length === 2) for (var r = 0, o3 = t.length, a2; r < o3; r++) (a2 || !(r in t)) && (a2 || (a2 = Array.prototype.slice.call(t, 0, r)), a2[r] = t[r]);
  return e.concat(a2 || Array.prototype.slice.call(t));
}
var N = [];
for (wt = 0; wt < 256; ++wt) N.push((wt + 256).toString(16).slice(1));
var wt;
function Un(e, t = 0) {
  return (N[e[t + 0]] + N[e[t + 1]] + N[e[t + 2]] + N[e[t + 3]] + "-" + N[e[t + 4]] + N[e[t + 5]] + "-" + N[e[t + 6]] + N[e[t + 7]] + "-" + N[e[t + 8]] + N[e[t + 9]] + "-" + N[e[t + 10]] + N[e[t + 11]] + N[e[t + 12]] + N[e[t + 13]] + N[e[t + 14]] + N[e[t + 15]]).toLowerCase();
}
var bt;
var Kr = new Uint8Array(16);
function Mt() {
  if (!bt && (bt = typeof crypto != "undefined" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !bt)) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
  return bt(Kr);
}
var eo = typeof crypto != "undefined" && crypto.randomUUID && crypto.randomUUID.bind(crypto);
var qt = { randomUUID: eo };
function to(e, t, n) {
  if (qt.randomUUID && !t && !e) return qt.randomUUID();
  e = e || {};
  var r = e.random || (e.rng || Mt)();
  if (r[6] = r[6] & 15 | 64, r[8] = r[8] & 63 | 128, t) {
    n = n || 0;
    for (var o3 = 0; o3 < 16; ++o3) t[n + o3] = r[o3];
    return t;
  }
  return Un(r);
}
var te = to;
var no = "4.6.3";
function ro(e) {
  if (!e) return e;
  var t = 4 - e.length % 4;
  switch (t) {
    case 2:
      e += "==";
      break;
    case 3:
      e += "=";
      break;
  }
  var n = e.replace(/-/g, "+").replace(/_/g, "/");
  return ao(n);
}
function oo(e) {
  if (!e) return e;
  var t = io(e);
  return t.replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}
var we = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
function io(e) {
  var t, n, r, o3, a2, u2, c2, f2, s2 = 0, l2 = 0, v2 = [];
  if (!e) return e;
  e = unescape(encodeURIComponent(e));
  do
    t = e.charCodeAt(s2++), n = e.charCodeAt(s2++), r = e.charCodeAt(s2++), f2 = t << 16 | n << 8 | r, o3 = f2 >> 18 & 63, a2 = f2 >> 12 & 63, u2 = f2 >> 6 & 63, c2 = f2 & 63, v2[l2++] = we.charAt(o3) + we.charAt(a2) + we.charAt(u2) + we.charAt(c2);
  while (s2 < e.length);
  var m = v2.join(""), y = e.length % 3;
  return (y ? m.slice(0, y - 3) : m) + "===".slice(y || 3);
}
function ao(e) {
  var t = function(w) {
    return decodeURIComponent(w.split("").map(function(g2) {
      return "%" + ("00" + g2.charCodeAt(0).toString(16)).slice(-2);
    }).join(""));
  }, n, r, o3, a2, u2, c2, f2, s2, l2 = 0, v2 = 0, m = "", y = [];
  if (!e) return e;
  e += "";
  do
    a2 = we.indexOf(e.charAt(l2++)), u2 = we.indexOf(e.charAt(l2++)), c2 = we.indexOf(e.charAt(l2++)), f2 = we.indexOf(e.charAt(l2++)), s2 = a2 << 18 | u2 << 12 | c2 << 6 | f2, n = s2 >> 16 & 255, r = s2 >> 8 & 255, o3 = s2 & 255, c2 === 64 ? y[v2++] = String.fromCharCode(n) : f2 === 64 ? y[v2++] = String.fromCharCode(n, r) : y[v2++] = String.fromCharCode(n, r, o3);
  while (l2 < e.length);
  return m = y.join(""), t(m.replace(/\0+$/, ""));
}
function Pt() {
  var e = {}, t = [], n = [], r = [], o3, a2 = function(s2, l2) {
    l2 != null && l2 !== "" && (e[s2] = l2);
  }, u2 = function(s2) {
    for (var l2 in s2) Object.prototype.hasOwnProperty.call(s2, l2) && a2(l2, s2[l2]);
  }, c2 = function(s2, l2, v2) {
    if (v2 && zn(v2)) {
      var m = { keyIfEncoded: s2, keyIfNotEncoded: l2, json: v2 };
      n.push(m), t.push(m);
    }
  }, f2 = function(s2) {
    r.push(s2);
  };
  return { add: a2, addDict: u2, addJson: c2, addContextEntity: f2, getPayload: function() {
    return e;
  }, getJson: function() {
    return t;
  }, withJsonProcessor: function(s2) {
    o3 = s2;
  }, build: function() {
    return o3 == null || o3(this, n, r), e;
  } };
}
function uo(e) {
  return function(t, n, r) {
    for (var o3 = function(m, y, w) {
      var g2 = JSON.stringify(m);
      e ? t.add(y, oo(g2)) : t.add(w, g2);
    }, a2 = function() {
      var m = t.getPayload();
      if (e ? m.cx : m.co) return JSON.parse(e ? ro(m.cx) : m.co);
    }, u2 = function(m, y) {
      var w = m || a2();
      return w ? w.data = w.data.concat(y.data) : w = y, w;
    }, c2 = void 0, f2 = 0, s2 = n; f2 < s2.length; f2++) {
      var l2 = s2[f2];
      l2.keyIfEncoded === "cx" ? c2 = u2(c2, l2.json) : o3(l2.json, l2.keyIfEncoded, l2.keyIfNotEncoded);
    }
    if (n.length = 0, r.length) {
      var v2 = { schema: "iglu:com.snowplowanalytics.snowplow/contexts/jsonschema/1-0-0", data: W([], r, true) };
      c2 = u2(c2, v2), r.length = 0;
    }
    c2 && o3(c2, "cx", "co");
  };
}
function zn(e) {
  if (!Bn(e)) return false;
  for (var t in e) if (Object.prototype.hasOwnProperty.call(e, t)) return true;
  return false;
}
function Bn(e) {
  return typeof e != "undefined" && e !== null && (e.constructor === {}.constructor || e.constructor === [].constructor);
}
var St = "Snowplow: ";
var fe;
(function(e) {
  e[e.none = 0] = "none", e[e.error = 1] = "error", e[e.warn = 2] = "warn", e[e.debug = 3] = "debug", e[e.info = 4] = "info";
})(fe || (fe = {}));
var L = so();
function so(e) {
  e === void 0 && (e = fe.warn);
  function t(u2) {
    fe[u2] ? e = u2 : e = fe.warn;
  }
  function n(u2, c2) {
    for (var f2 = [], s2 = 2; s2 < arguments.length; s2++) f2[s2 - 2] = arguments[s2];
    if (e >= fe.error && typeof console != "undefined") {
      var l2 = St + u2 + `
`;
      c2 ? console.error.apply(console, W([l2 + `
`, c2], f2, false)) : console.error.apply(console, W([l2], f2, false));
    }
  }
  function r(u2, c2) {
    for (var f2 = [], s2 = 2; s2 < arguments.length; s2++) f2[s2 - 2] = arguments[s2];
    if (e >= fe.warn && typeof console != "undefined") {
      var l2 = St + u2;
      c2 ? console.warn.apply(console, W([l2 + `
`, c2], f2, false)) : console.warn.apply(console, W([l2], f2, false));
    }
  }
  function o3(u2) {
    for (var c2 = [], f2 = 1; f2 < arguments.length; f2++) c2[f2 - 1] = arguments[f2];
    e >= fe.debug && typeof console != "undefined" && console.debug.apply(console, W([St + u2], c2, false));
  }
  function a2(u2) {
    for (var c2 = [], f2 = 1; f2 < arguments.length; f2++) c2[f2 - 1] = arguments[f2];
    e >= fe.info && typeof console != "undefined" && console.info.apply(console, W([St + u2], c2, false));
  }
  return { setLogLevel: t, warn: r, error: n, debug: o3, info: a2 };
}
function co() {
  var e = [], t = [], n = {}, r = {}, o3 = function(a2) {
    var u2 = yo(a2), c2 = wo(a2), f2 = [], s2 = Gt(e.concat(Object.values(n)), a2, c2, u2);
    f2.push.apply(f2, s2);
    var l2 = Io(t.concat(Object.values(r)), a2, c2, u2);
    return f2.push.apply(f2, l2), f2;
  };
  return { getGlobalPrimitives: function() {
    return e.concat(Object.values(n));
  }, getConditionalProviders: function() {
    return t.concat(Object.values(r));
  }, addGlobalContexts: function(a2) {
    if (Array.isArray(a2)) {
      for (var u2 = [], c2 = [], f2 = 0, s2 = a2; f2 < s2.length; f2++) {
        var l2 = s2[f2];
        Xe(l2) ? u2.push(l2) : de(l2) && c2.push(l2);
      }
      e = e.concat(c2), t = t.concat(u2);
    } else for (var v2 = 0, m = Object.entries(a2); v2 < m.length; v2++) {
      var y = m[v2], w = y[0], l2 = y[1];
      Xe(l2) ? r[w] = l2 : de(l2) && (n[w] = l2);
    }
  }, clearGlobalContexts: function() {
    t = [], e = [], r = {}, n = {};
  }, removeGlobalContexts: function(a2) {
    for (var u2 = function(l2) {
      typeof l2 == "string" ? (delete r[l2], delete n[l2]) : Xe(l2) ? t = t.filter(function(v2) {
        return !Vn(l2, v2);
      }) : de(l2) && (e = e.filter(function(v2) {
        return !Vn(l2, v2);
      }));
    }, c2 = 0, f2 = a2; c2 < f2.length; c2++) {
      var s2 = f2[c2];
      u2(s2);
    }
  }, getApplicableContexts: function(a2) {
    return o3(a2);
  } };
}
function lo(e) {
  return { addPluginContexts: function(t) {
    var n = t ? W([], t, true) : [];
    return e.forEach(function(r) {
      try {
        r.contexts && n.push.apply(n, r.contexts());
      } catch (o3) {
        L.error("Error adding plugin contexts", o3);
      }
    }), n;
  } };
}
function fo(e) {
  var t = new RegExp("^iglu:([a-zA-Z0-9-_.]+)/([a-zA-Z0-9-_]+)/jsonschema/([1-9][0-9]*)-(0|[1-9][0-9]*)-(0|[1-9][0-9]*)$"), n = t.exec(e);
  if (n !== null) return n.slice(1, 6);
}
function vo(e) {
  if (e[0] === "*" || e[1] === "*") return false;
  if (e.slice(2).length > 0) {
    for (var t = false, n = 0, r = e.slice(2); n < r.length; n++) {
      var o3 = r[n];
      if (o3 === "*") t = true;
      else if (t) return false;
    }
    return true;
  } else if (e.length == 2) return true;
  return false;
}
function Ln(e) {
  var t = e.split(".");
  return t && t.length > 1 ? vo(t) : false;
}
function Mn(e) {
  var t = new RegExp("^iglu:((?:(?:[a-zA-Z0-9-_]+|\\*).)+(?:[a-zA-Z0-9-_]+|\\*))/([a-zA-Z0-9-_.]+|\\*)/jsonschema/([1-9][0-9]*|\\*)-(0|[1-9][0-9]*|\\*)-(0|[1-9][0-9]*|\\*)$"), n = t.exec(e);
  if (n !== null && Ln(n[1])) return n.slice(1, 6);
}
function Ht(e) {
  var t = Mn(e);
  if (t) {
    var n = t[0];
    return t.length === 5 && Ln(n);
  }
  return false;
}
function mo(e) {
  return Array.isArray(e) && e.every(function(t) {
    return typeof t == "string";
  });
}
function jn(e) {
  return mo(e) ? e.every(function(t) {
    return Ht(t);
  }) : typeof e == "string" ? Ht(e) : false;
}
function Ye(e) {
  var t = e;
  return zn(t) && "schema" in t && "data" in t ? typeof t.schema == "string" && typeof t.data == "object" : false;
}
function po(e) {
  var t = e, n = 0;
  if (e != null && typeof e == "object" && !Array.isArray(e)) {
    if (Object.prototype.hasOwnProperty.call(t, "accept")) if (jn(t.accept)) n += 1;
    else return false;
    if (Object.prototype.hasOwnProperty.call(t, "reject")) if (jn(t.reject)) n += 1;
    else return false;
    return n > 0 && n <= 2;
  }
  return false;
}
function Tt(e) {
  return typeof e == "function" && e.length <= 1;
}
function de(e) {
  return Tt(e) || Ye(e);
}
function qn(e) {
  return Array.isArray(e) && e.length === 2 ? Array.isArray(e[1]) ? Tt(e[0]) && e[1].every(de) : Tt(e[0]) && de(e[1]) : false;
}
function Hn(e) {
  return Array.isArray(e) && e.length === 2 && po(e[0]) ? Array.isArray(e[1]) ? e[1].every(de) : de(e[1]) : false;
}
function Xe(e) {
  return qn(e) || Hn(e);
}
function go(e, t) {
  var n = 0, r = 0, o3 = e.accept;
  Array.isArray(o3) ? e.accept.some(function(u2) {
    return xt(u2, t);
  }) && r++ : typeof o3 == "string" && xt(o3, t) && r++;
  var a2 = e.reject;
  return Array.isArray(a2) ? e.reject.some(function(u2) {
    return xt(u2, t);
  }) && n++ : typeof a2 == "string" && xt(a2, t) && n++, r > 0 && n === 0 ? true : (r === 0 && n > 0, false);
}
function xt(e, t) {
  if (!Ht(e)) return false;
  var n = Mn(e), r = fo(t);
  if (n && r) {
    if (!ho(n[0], r[0])) return false;
    for (var o3 = 1; o3 < 5; o3++) if (!Gn(n[o3], r[o3])) return false;
    return true;
  }
  return false;
}
function ho(e, t) {
  var n = t.split("."), r = e.split(".");
  if (n && r) {
    if (n.length !== r.length) return false;
    for (var o3 = 0; o3 < r.length; o3++) if (!Gn(n[o3], r[o3])) return false;
    return true;
  }
  return false;
}
function Gn(e, t) {
  return e && t && e === "*" || e === t;
}
function yo(e) {
  for (var t = e.getJson(), n = 0, r = t; n < r.length; n++) {
    var o3 = r[n];
    if (o3.keyIfEncoded === "ue_px" && typeof o3.json.data == "object") {
      var a2 = o3.json.data.schema;
      if (typeof a2 == "string") return a2;
    }
  }
  return "";
}
function wo(e) {
  var t = e.getPayload().e;
  return typeof t == "string" ? t : "";
}
function bo(e, t, n, r) {
  var o3 = void 0;
  try {
    var a2 = { event: t.getPayload(), eventType: n, eventSchema: r };
    return o3 = e(a2), Array.isArray(o3) && o3.every(Ye) || Ye(o3) ? o3 : void 0;
  } catch (u2) {
    o3 = void 0;
  }
  return o3;
}
function Jn(e) {
  return Array.isArray(e) ? e : Array.of(e);
}
function Gt(e, t, n, r) {
  var o3, a2 = Jn(e), u2 = function(f2) {
    var s2 = So(f2, t, n, r);
    if (s2 && s2.length !== 0) return s2;
  }, c2 = a2.map(u2);
  return (o3 = []).concat.apply(o3, c2.filter(function(f2) {
    return f2 != null && f2.filter(Boolean);
  }));
}
function So(e, t, n, r) {
  if (Ye(e)) return [e];
  if (Tt(e)) {
    var o3 = bo(e, t, n, r);
    if (Ye(o3)) return [o3];
    if (Array.isArray(o3)) return o3;
  }
}
function xo(e, t, n, r) {
  if (qn(e)) {
    var o3 = e[0], a2 = false;
    try {
      var u2 = { event: t.getPayload(), eventType: n, eventSchema: r };
      a2 = o3(u2);
    } catch (c2) {
      a2 = false;
    }
    if (a2 === true) return Gt(e[1], t, n, r);
  } else if (Hn(e) && go(e[0], r)) return Gt(e[1], t, n, r);
  return [];
}
function It(e, t) {
  return typeof e == "function" ? e === t : JSON.stringify(e) === JSON.stringify(t);
}
function Vn(e, t) {
  if (Xe(e)) {
    if (!Xe(t)) return false;
    var n = e[0], r = e[1], o3 = t[0], a2 = t[1];
    return It(n, o3) ? Array.isArray(r) ? !Array.isArray(a2) || r.length !== a2.length ? false : r.reduce(function(u2, c2, f2) {
      return u2 && It(c2, a2[f2]);
    }, true) : Array.isArray(a2) ? false : It(r, a2) : false;
  } else if (de(e)) return de(t) ? It(e, t) : false;
  return false;
}
function Io(e, t, n, r) {
  var o3, a2 = Jn(e), u2 = function(f2) {
    var s2 = xo(f2, t, n, r);
    if (s2 && s2.length !== 0) return s2;
  }, c2 = a2.map(u2);
  return (o3 = []).concat.apply(o3, c2.filter(function(f2) {
    return f2 != null && f2.filter(Boolean);
  }));
}
function To(e) {
  var t = e.payload, n = e.svrAnon, r = n === void 0 ? false : n;
  return { payload: t, svrAnon: r };
}
function Po(e) {
  return e == null ? { type: "dtm", value: (/* @__PURE__ */ new Date()).getTime() } : typeof e == "number" ? { type: "dtm", value: e } : e.type === "ttm" ? { type: "ttm", value: e.value } : { type: "dtm", value: e.value || (/* @__PURE__ */ new Date()).getTime() };
}
function Wn(e) {
  e === void 0 && (e = {});
  function t(s2, l2, v2) {
    var m = lo(l2), y = co(), w = s2, g2 = {};
    function P2(p2) {
      if (p2 && p2.length) return { schema: "iglu:com.snowplowanalytics.snowplow/contexts/jsonschema/1-0-0", data: p2 };
    }
    function q(p2, T) {
      var H = y.getApplicableContexts(p2), D = [];
      return T && T.length && D.push.apply(D, T), H && H.length && D.push.apply(D, H), D;
    }
    function Q(p2, T, H) {
      if (!n) {
        L.error("Track called on deactivated tracker");
        return;
      }
      p2.withJsonProcessor(uo(w)), p2.add("eid", te()), p2.addDict(g2);
      var D = Po(H);
      p2.add(D.type, D.value.toString());
      var X = q(p2, m.addPluginContexts(T)), ne = P2(X);
      ne !== void 0 && p2.addJson("cx", "co", ne), l2.forEach(function(F2) {
        try {
          F2.beforeTrack && F2.beforeTrack(p2);
        } catch (z) {
          L.error("Plugin beforeTrack", z);
        }
      });
      var ae = l2.find(function(F2) {
        try {
          return F2.filter && F2.filter(p2.build()) === false;
        } catch (z) {
          return L.error("Plugin filter", z), false;
        }
      });
      if (!ae) {
        typeof v2 == "function" && v2(p2);
        var ue = p2.build();
        return l2.forEach(function(F2) {
          try {
            F2.afterTrack && F2.afterTrack(ue);
          } catch (z) {
            L.error("Plugin afterTrack", z);
          }
        }), ue;
      }
    }
    function S2(p2, T) {
      g2[p2] = T;
    }
    var I2 = { track: Q, addPayloadPair: S2, getBase64Encoding: function() {
      return w;
    }, setBase64Encoding: function(p2) {
      w = p2;
    }, addPayloadDict: function(p2) {
      for (var T in p2) Object.prototype.hasOwnProperty.call(p2, T) && (g2[T] = p2[T]);
    }, resetPayloadPairs: function(p2) {
      g2 = Bn(p2) ? p2 : {};
    }, setTrackerVersion: function(p2) {
      S2("tv", p2);
    }, setTrackerNamespace: function(p2) {
      S2("tna", p2);
    }, setAppId: function(p2) {
      S2("aid", p2);
    }, setPlatform: function(p2) {
      S2("p", p2);
    }, setUserId: function(p2) {
      S2("uid", p2);
    }, setScreenResolution: function(p2, T) {
      S2("res", p2 + "x" + T);
    }, setViewport: function(p2, T) {
      S2("vp", p2 + "x" + T);
    }, setColorDepth: function(p2) {
      S2("cd", p2);
    }, setTimezone: function(p2) {
      S2("tz", p2);
    }, setLang: function(p2) {
      S2("lang", p2);
    }, setIpAddress: function(p2) {
      S2("ip", p2);
    }, setUseragent: function(p2) {
      S2("ua", p2);
    }, addGlobalContexts: function(p2) {
      y.addGlobalContexts(p2);
    }, clearGlobalContexts: function() {
      y.clearGlobalContexts();
    }, removeGlobalContexts: function(p2) {
      y.removeGlobalContexts(p2);
    } };
    return I2;
  }
  var n = true, r = e.base64, o3 = e.corePlugins, a2 = e.callback, u2 = o3 != null ? o3 : [], c2 = t(r != null ? r : true, u2, a2), f2 = V2(V2({}, c2), { addPlugin: function(s2) {
    var l2, v2, m = s2.plugin;
    u2.push(m), (l2 = m.logger) === null || l2 === void 0 || l2.call(m, L), (v2 = m.activateCorePlugin) === null || v2 === void 0 || v2.call(m, f2);
  }, deactivate: function() {
    u2.forEach(function(s2) {
      var l2;
      (l2 = s2.deactivatePlugin) === null || l2 === void 0 || l2.call(s2, f2);
    }), u2.length = 0, n = false;
  } });
  return u2 == null || u2.forEach(function(s2) {
    var l2, v2;
    (l2 = s2.logger) === null || l2 === void 0 || l2.call(s2, L), (v2 = s2.activateCorePlugin) === null || v2 === void 0 || v2.call(s2, f2);
  }), f2;
}
function Xn(e) {
  var t = e.event, n = t.schema, r = t.data, o3 = Pt(), a2 = { schema: "iglu:com.snowplowanalytics.snowplow/unstruct_event/jsonschema/1-0-0", data: { schema: n, data: r } };
  return o3.add("e", "ue"), o3.addJson("ue_px", "ue_pr", a2), o3;
}
function Yn(e) {
  var t = e.pageUrl, n = e.pageTitle, r = e.referrer, o3 = Pt();
  return o3.add("e", "pv"), o3.add("url", t), o3.add("page", n), o3.add("refr", r), o3;
}
function Qn(e) {
  var t = e.pageUrl, n = e.pageTitle, r = e.referrer, o3 = e.minXOffset, a2 = e.maxXOffset, u2 = e.minYOffset, c2 = e.maxYOffset, f2 = Pt();
  return f2.add("e", "pp"), f2.add("url", t), f2.add("page", n), f2.add("refr", r), o3 && !isNaN(Number(o3)) && f2.add("pp_mix", o3.toString()), a2 && !isNaN(Number(a2)) && f2.add("pp_max", a2.toString()), u2 && !isNaN(Number(u2)) && f2.add("pp_miy", u2.toString()), c2 && !isNaN(Number(c2)) && f2.add("pp_may", c2.toString()), f2;
}
function Zn(e) {
  var t = e.category, n = e.action, r = e.label, o3 = e.property, a2 = e.value, u2 = Pt();
  return u2.add("e", "se"), u2.add("se_ca", t), u2.add("se_ac", n), u2.add("se_la", r), u2.add("se_pr", o3), u2.add("se_va", a2 == null ? void 0 : a2.toString()), u2;
}
function Ct(e) {
  var t = e.maxSize, n = t === void 0 ? 1e3 : t, r = e.events, o3 = r === void 0 ? [] : r, a2 = W([], o3, true), u2 = function() {
    return Promise.resolve(a2.length);
  };
  return { count: u2, add: function(c2) {
    for (a2.push(c2); a2.length > n; ) a2.shift();
    return u2();
  }, removeHead: function(c2) {
    for (var f2 = 0; f2 < c2; f2++) a2.shift();
    return Promise.resolve();
  }, iterator: function() {
    var c2 = 0, f2 = W([], a2, true);
    return { next: function() {
      return c2 < f2.length ? Promise.resolve({ value: f2[c2++], done: false }) : Promise.resolve({ value: void 0, done: true });
    } };
  }, getAll: function() {
    return Promise.resolve(W([], a2, true));
  }, getAllPayloads: function() {
    return Promise.resolve(a2.map(function(c2) {
      return c2.payload;
    }));
  } };
}
var Co = "iglu:com.snowplowanalytics.snowplow/payload_data/jsonschema/1-0-4";
function Ao(e) {
  return JSON.stringify({ schema: Co, data: e });
}
function ko(e) {
  for (var t = (/* @__PURE__ */ new Date()).getTime().toString(), n = 0; n < e.length; n++) e[n].stm = t;
  return e;
}
function Oo(e) {
  var t = e.endpoint, n = e.protocol, r = n === void 0 ? "https" : n, o3 = e.port, a2 = e.eventMethod, u2 = a2 === void 0 ? "post" : a2, c2 = e.customHeaders, f2 = e.connectionTimeout, s2 = e.keepalive, l2 = s2 === void 0 ? false : s2, v2 = e.postPath, m = v2 === void 0 ? "/com.snowplowanalytics.snowplow/tp2" : v2, y = e.useStm, w = y === void 0 ? true : y, g2 = e.maxPostBytes, P2 = g2 === void 0 ? 4e4 : g2, q = e.credentials, Q = q === void 0 ? "include" : q, S2 = [], I2 = u2.toLowerCase() === "post", p2, T;
  function H() {
    var C2 = S2.reduce(function(R, Z) {
      return R + (I2 ? Z.getPOSTRequestBytesCount() : Z.getGETRequestBytesCount());
    }, 0);
    return I2 && (C2 += 88), C2;
  }
  function D() {
    return S2.length;
  }
  function X() {
    return S2.length > 0 ? S2[0].getServerAnonymization() : void 0;
  }
  function ne(C2) {
    return S2.length > 0 && X() !== C2.getServerAnonymization() ? false : (S2.push(C2), true);
  }
  function ae() {
    return S2;
  }
  function ue() {
    return I2 ? H() >= P2 : S2.length >= 1;
  }
  function F2() {
    var C2 = new Headers();
    return I2 && C2.append("Content-Type", "application/json; charset=UTF-8"), c2 && Object.keys(c2).forEach(function(R) {
      C2.append(R, c2[R]);
    }), X() && C2.append("SP-Anonymous", "*"), C2;
  }
  function z() {
    var C2 = t;
    t.includes("://") || (C2 = "".concat(r, "://").concat(t)), o3 && (C2 = "".concat(C2, ":").concat(o3));
    var R = I2 ? m : "/i";
    return C2 + R;
  }
  function me(C2, R) {
    ce(false), T = new AbortController(), p2 = setTimeout(function() {
      var De = "Request timed out";
      console.error(De), p2 = void 0, ce(false, De);
    }, f2 != null ? f2 : 5e3);
    var Z = V2({ headers: F2(), signal: T.signal, keepalive: l2, credentials: Q }, R), Te = new Request(C2, Z);
    return Te;
  }
  function pe() {
    var C2 = ko(S2.map(function(R) {
      return R.getPOSTRequestBody();
    }));
    return me(z(), { method: "POST", body: Ao(C2) });
  }
  function se() {
    if (S2.length !== 1) throw new Error("Only one event can be sent in a GET request");
    var C2 = S2[0], R = C2.getGETRequestURL(z(), w);
    return me(R, { method: "GET" });
  }
  function Ie() {
    if (S2.length !== 0) return I2 ? pe() : se();
  }
  function ce(C2, R) {
    if (p2 !== void 0 && (clearTimeout(p2), p2 = void 0), T !== void 0) {
      var Z = T;
      T = void 0, C2 || Z.abort(R);
    }
  }
  return { addEvent: ne, getEvents: ae, toRequest: Ie, countBytes: H, countEvents: D, isFull: ue, closeRequest: ce };
}
function Fn(e) {
  for (var t = 0, n = 0; n < e.length; n++) {
    var r = e.charCodeAt(n);
    r <= 127 ? t += 1 : r <= 2047 ? t += 2 : r >= 55296 && r <= 57343 ? (t += 4, n++) : r < 65535 ? t += 3 : t += 4;
  }
  return t;
}
function Eo(e) {
  var t = { co: true, cx: true }, n = [];
  for (var r in e) e.hasOwnProperty(r) && !t[r] && n.push(r + "=" + encodeURIComponent(e[r]));
  for (var o3 in t) e.hasOwnProperty(o3) && t[o3] && n.push(o3 + "=" + encodeURIComponent(e[o3]));
  return "?" + n.join("&");
}
function _o(e) {
  var t = Object.keys(e).map(function(n) {
    return [n, e[n]];
  }).reduce(function(n, r) {
    var o3 = r[0], a2 = r[1];
    return n[o3] = a2.toString(), n;
  }, {});
  return t;
}
function Nn(e) {
  var t = null, n = null, r = null, o3 = null;
  function a2() {
    return e.payload;
  }
  function u2() {
    var m;
    return (m = e.svrAnon) !== null && m !== void 0 ? m : false;
  }
  function c2(m) {
    return t === null && (t = Eo(m)), t;
  }
  function f2(m, y) {
    var w = c2(a2());
    return y ? m + w.replace("?", "?stm=" + (/* @__PURE__ */ new Date()).getTime() + "&") : m + w;
  }
  function s2() {
    if (r === null) {
      var m = c2(a2());
      r = Fn(m);
    }
    return r;
  }
  function l2() {
    return n === null && (n = _o(a2())), n;
  }
  function v2() {
    return o3 === null && (o3 = Fn(JSON.stringify(l2()))), o3;
  }
  return { getPayload: a2, getServerAnonymization: u2, getGETRequestURL: f2, getGETRequestBytesCount: s2, getPOSTRequestBody: l2, getPOSTRequestBytesCount: v2 };
}
function $n(e) {
  var t = e.endpoint, n = e.eventMethod, r = n === void 0 ? "post" : n, o3 = e.postPath, a2 = e.protocol, u2 = e.port, c2 = e.maxPostBytes, f2 = c2 === void 0 ? 4e4 : c2, s2 = e.maxGetBytes, l2 = e.bufferSize, v2 = l2 === void 0 ? 1 : l2, m = e.customHeaders, y = e.serverAnonymization, w = e.connectionTimeout, g2 = e.keepalive, P2 = e.cookieExtensionService, q = e.idService, Q = e.dontRetryStatusCodes, S2 = Q === void 0 ? [] : Q, I2 = e.retryStatusCodes, p2 = I2 === void 0 ? [] : I2, T = e.retryFailedRequests, H = T === void 0 ? true : T, D = e.onRequestFailure, X = e.onRequestSuccess, ne = e.customFetch, ae = ne === void 0 ? fetch : ne, ue = e.useStm, F2 = e.eventStore, z = F2 === void 0 ? Ct({}) : F2, me = e.credentials;
  P2 = P2 || q;
  var pe = false, se = false, Ie = r.toLowerCase() === "post";
  S2 = S2.concat([400, 401, 403, 410, 422]);
  function ce(b) {
    return b >= 200 && b < 300 || !H ? false : p2.includes(b) ? true : !S2.includes(b);
  }
  function C2(b, x) {
    X !== void 0 && setTimeout(function() {
      try {
        X == null || X(b, x);
      } catch (k2) {
        L.error("Error in onRequestSuccess", k2);
      }
    }, 0);
  }
  function R(b, x) {
    D !== void 0 && setTimeout(function() {
      try {
        D == null || D(b, x);
      } catch (k2) {
        L.error("Error in onRequestFailure", k2);
      }
    }, 0);
  }
  function Z(b) {
    return ze(this, void 0, void 0, function() {
      var x, k2, O, G, U, M2;
      return Be(this, function(j) {
        switch (j.label) {
          case 0:
            if (x = b.toRequest(), x === void 0) throw new Error("Empty batch");
            k2 = b.getEvents().map(function(re) {
              return re.getPayload();
            }), j.label = 1;
          case 1:
            return j.trys.push([1, 4, , 5]), [4, ae(x)];
          case 2:
            return O = j.sent(), [4, O.text()];
          case 3:
            return j.sent(), b.closeRequest(true), O.ok ? (C2(k2, O), [2, { success: true, retry: false, status: O.status }]) : (G = ce(O.status), R({ events: k2, status: O.status, message: O.statusText, willRetry: G }, O), [2, { success: false, retry: G, status: O.status }]);
          case 4:
            return U = j.sent(), b.closeRequest(false), M2 = typeof U == "string" ? U : U ? U.message : "Unknown error", R({ events: k2, message: M2, willRetry: true }), [2, { success: false, retry: true }];
          case 5:
            return [2];
        }
      });
    });
  }
  function Te() {
    return Oo({ endpoint: t, protocol: a2, port: u2, eventMethod: r, customHeaders: m, connectionTimeout: w, keepalive: g2, maxPostBytes: f2, useStm: ue, credentials: me, postPath: o3 });
  }
  function De(b) {
    var x = function(G, U) {
      return L.warn("Event (" + G + "B) too big, max is " + U);
    };
    if (Ie) {
      var k2 = b.getPOSTRequestBytesCount() + 88, O = k2 > f2;
      return O && x(k2, f2), O;
    } else {
      if (s2 === void 0) return false;
      var k2 = b.getGETRequestBytesCount(), O = k2 > s2;
      return O && x(k2, s2), O;
    }
  }
  function tt() {
    return ze(this, void 0, void 0, function() {
      var b;
      return Be(this, function(x) {
        switch (x.label) {
          case 0:
            return P2 && !pe ? (pe = true, b = new Request(P2, { method: "GET" }), [4, ae(b)]) : [3, 2];
          case 1:
            x.sent(), x.label = 2;
          case 2:
            return [2];
        }
      });
    });
  }
  function nt() {
    return ze(this, void 0, void 0, function() {
      var b;
      return Be(this, function(x) {
        switch (x.label) {
          case 0:
            if (se) return [3, 5];
            se = true, x.label = 1;
          case 1:
            return x.trys.push([1, 3, 4, 5]), [4, $()];
          case 2:
            return x.sent(), [3, 5];
          case 3:
            return b = x.sent(), L.error("Error sending events", b), [3, 5];
          case 4:
            return se = false, [7];
          case 5:
            return [2];
        }
      });
    });
  }
  function $() {
    return ze(this, void 0, void 0, function() {
      var b, x, k2, O, G, U, M2, j, re, Ue;
      return Be(this, function(oe) {
        switch (oe.label) {
          case 0:
            return [4, tt()];
          case 1:
            oe.sent(), b = Te(), x = z.iterator(), oe.label = 2;
          case 2:
            return b.isFull() ? [3, 4] : [4, x.next()];
          case 3:
            return k2 = oe.sent(), O = k2.value, G = k2.done, G || O === void 0 ? [3, 4] : (U = Nn(O), b.addEvent(U) ? [3, 2] : [3, 4]);
          case 4:
            return b.countEvents() === 0 ? [2] : [4, Z(b)];
          case 5:
            return M2 = oe.sent(), j = M2.success, re = M2.retry, Ue = M2.status, j || !re ? (j || L.error("Status ".concat(Ue, ", will not retry.")), [4, z.removeHead(b.countEvents())]) : [3, 7];
          case 6:
            oe.sent(), oe.label = 7;
          case 7:
            return j ? [4, $()] : [3, 9];
          case 8:
            oe.sent(), oe.label = 9;
          case 9:
            return [2];
        }
      });
    });
  }
  function B(b) {
    return ze(this, void 0, void 0, function() {
      var x, k2, O, G;
      return Be(this, function(U) {
        switch (U.label) {
          case 0:
            return x = To({ payload: b, svrAnon: y }), k2 = Nn(x), De(k2) ? (O = Te(), O.addEvent(k2), [4, Z(O)]) : [3, 2];
          case 1:
            return U.sent(), [3, 5];
          case 2:
            return [4, z.add(x)];
          case 3:
            return G = U.sent(), G >= v2 ? [4, nt()] : [3, 5];
          case 4:
            U.sent(), U.label = 5;
          case 5:
            return [2];
        }
      });
    });
  }
  function Ot(b) {
    t = b;
  }
  function le(b) {
    y = b;
  }
  function rt(b) {
    v2 = b;
  }
  return { flush: nt, input: B, setCollectorUrl: Ot, setAnonymousTracking: le, setBufferSize: rt };
}
var Kn = no;
var mr = $r(or());
function Ro(e) {
  try {
    var t = window.localStorage, n = t.getItem(e + ".expires");
    if (n === null || +n > Date.now()) return t.getItem(e);
    t.removeItem(e), t.removeItem(e + ".expires");
    return;
  } catch (r) {
    return;
  }
}
function Do(e, t, n) {
  n === void 0 && (n = 63072e3);
  try {
    var r = window.localStorage, o3 = Date.now() + n * 1e3;
    return r.setItem("".concat(e, ".expires"), o3.toString()), r.setItem(e, t), true;
  } catch (a2) {
    return false;
  }
}
function ir(e) {
  try {
    var t = window.localStorage;
    return t.removeItem(e), t.removeItem(e + ".expires"), true;
  } catch (n) {
    return false;
  }
}
function ar(e) {
  try {
    return window.sessionStorage.getItem(e);
  } catch (t) {
    return;
  }
}
function Uo(e, t) {
  try {
    return window.sessionStorage.setItem(e, t), true;
  } catch (n) {
    return false;
  }
}
var jo = { sessionId: true, sourceId: true, sourcePlatform: false, userId: false, reason: false };
function Vo(e, t, n) {
  var r, o3, a2 = (/* @__PURE__ */ new Date()).getTime(), u2 = V2(V2({}, jo), t), c2 = n.domainUserId, f2 = n.userId, s2 = n.sessionId, l2 = n.sourceId, v2 = n.sourcePlatform, m = n.event, y = m.currentTarget, w = typeof u2.reason == "function" ? u2.reason(m) : (r = y == null ? void 0 : y.textContent) === null || r === void 0 ? void 0 : r.trim();
  return e ? o3 = [c2, a2, u2.sessionId && s2, u2.userId && Xt(f2 || ""), u2.sourceId && Xt(l2 || ""), u2.sourcePlatform && v2, u2.reason && Xt(w || "")].map(function(g2) {
    return g2 || "";
  }).join(".").replace(/([.]*$)/, "") : o3 = n.domainUserId + "." + a2, o3;
}
function Xt(e) {
  return btoa(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/\=+$/, "");
}
function Fo(e) {
  return !!(e && typeof e.valueOf() == "string");
}
function ur(e) {
  return Number.isInteger && Number.isInteger(e) || typeof e == "number" && isFinite(e) && Math.floor(e) === e;
}
function No() {
  if (typeof Intl == "object" && typeof Intl.DateTimeFormat == "function") {
    var e = new Intl.DateTimeFormat().resolvedOptions();
    return e.timeZone;
  }
}
function sr(e) {
  if (!Fo(e)) {
    e = e.text || "";
    var t = document.getElementsByTagName("title");
    t && t[0] != null && (e = t[0].text);
  }
  return e;
}
function nn(e) {
  var t = new RegExp("^(?:(?:https?|ftp):)/*(?:[^@]+@)?([^:/#]+)"), n = t.exec(e);
  return n ? n[1] : e;
}
function cr(e) {
  var t = e.length;
  return e.charAt(--t) === "." && (e = e.slice(0, t)), e.slice(0, 2) === "*." && (e = e.slice(1)), e;
}
function Yt(e) {
  var t = window, n = $e("referrer", t.location.href) || $e("referer", t.location.href);
  if (n) return n;
  if (e) return e;
  try {
    if (t.top) return t.top.document.referrer;
    if (t.parent) return t.parent.document.referrer;
  } catch (r) {
  }
  return document.referrer;
}
function Le(e, t, n, r) {
  if (e.addEventListener) return e.addEventListener(t, n, r), true;
  if (e.attachEvent) return e.attachEvent("on" + t, n);
  e["on" + t] = n;
}
function $e(e, t) {
  var n = new RegExp("^[^#]*[?&]" + e + "=([^&#]*)").exec(t);
  return n ? decodeURIComponent(n[1].replace(/\+/g, " ")) : null;
}
function zo(e, t, n) {
  var r = t + "=" + n, o3 = e.split("#"), a2 = o3[0].split("?"), u2 = a2.shift(), c2 = a2.join("?");
  if (!c2) c2 = r;
  else {
    for (var f2 = true, s2 = c2.split("&"), l2 = 0; l2 < s2.length; l2++) if (s2[l2].substr(0, t.length + 1) === t + "=") {
      f2 = false, s2[l2] = r, c2 = s2.join("&");
      break;
    }
    f2 && (c2 = r + "&" + c2);
  }
  return o3[0] = u2 + "?" + c2, o3.join("#");
}
function Bo(e, t) {
  for (var n = window.location.hostname, r = "_sp_root_domain_test_", o3 = r + (/* @__PURE__ */ new Date()).getTime(), a2 = "_test_value_" + (/* @__PURE__ */ new Date()).getTime(), u2 = n.split("."), c2 = u2.length - 2; c2 >= 0; c2--) {
    var f2 = u2.slice(c2).join(".");
    if (xe(o3, a2, 0, "/", f2, e, t), xe(o3) === a2) {
      kt(o3, "/", f2, e, t);
      for (var s2 = Lo(r), l2 = 0; l2 < s2.length; l2++) kt(s2[l2], "/", f2, e, t);
      return f2;
    }
  }
  return n;
}
function kt(e, t, n, r, o3) {
  xe(e, "", -1, t, n, r, o3);
}
function Lo(e) {
  for (var t = document.cookie.split("; "), n = [], r = 0; r < t.length; r++) t[r].substring(0, e.length) === e && n.push(t[r]);
  return n;
}
function xe(e, t, n, r, o3, a2, u2) {
  return arguments.length > 1 ? document.cookie = e + "=" + encodeURIComponent(t != null ? t : "") + (n ? "; Expires=" + new Date(+/* @__PURE__ */ new Date() + n * 1e3).toUTCString() : "") + (r ? "; Path=" + r : "") + (o3 ? "; Domain=" + o3 : "") + (a2 ? "; SameSite=" + a2 : "") + (u2 ? "; Secure" : "") : decodeURIComponent((("; " + document.cookie).split("; " + e + "=")[1] || "").split(";")[0]);
}
function Mo(e) {
  var t = e.trackerId, n = e.maxLocalStorageQueueSize, r = n === void 0 ? 1e3 : n, o3 = e.useLocalStorage, a2 = o3 === void 0 ? true : o3, u2 = "snowplowOutQueue_".concat(t);
  function c2() {
    if (a2) {
      var P2 = window.localStorage.getItem(u2), q = P2 ? JSON.parse(P2) : [];
      return Ct({ maxSize: r, events: q });
    } else return Ct({ maxSize: r });
  }
  var f2 = c2(), s2 = f2.getAll, l2 = f2.getAllPayloads, v2 = f2.add, m = f2.count, y = f2.iterator, w = f2.removeHead;
  function g2() {
    return a2 ? s2().then(function(P2) {
      window.localStorage.setItem(u2, JSON.stringify(P2));
    }) : Promise.resolve();
  }
  return { count: m, add: function(P2) {
    return v2(P2), g2().then(m);
  }, removeHead: function(P2) {
    return w(P2), g2();
  }, iterator: y, getAll: s2, getAllPayloads: l2, setUseLocalStorage: function(P2) {
    a2 = P2;
  } };
}
function qo(e, t) {
  var n, r = (n = e.eventStore) !== null && n !== void 0 ? n : Mo(e);
  e.eventStore = r;
  var o3 = $n(e);
  return t.bufferFlushers.push(o3.flush), { enqueueRequest: o3.input, executeQueue: o3.flush, setAnonymousTracking: o3.setAnonymousTracking, setCollectorUrl: o3.setCollectorUrl, setBufferSize: o3.setBufferSize, setUseLocalStorage: function(a2) {
    if (r.hasOwnProperty("setUseLocalStorage")) {
      var u2 = r;
      u2.setUseLocalStorage(a2);
    }
  } };
}
function Ho(e, t) {
  var n = new RegExp("^(?:https?|ftp)(?::/*(?:[^?]+))([?][^#]+)"), r = n.exec(e);
  return r && (r == null ? void 0 : r.length) > 1 ? $e(t, r[1]) : null;
}
function lr(e, t, n) {
  var r;
  return e === "translate.googleusercontent.com" ? (n === "" && (n = t), t = (r = Ho(t, "u")) !== null && r !== void 0 ? r : "", e = nn(t)) : (e === "cc.bingj.com" || e === "webcache.googleusercontent.com") && (t = document.links[0].href, e = nn(t)), [e, t, n];
}
var pr = 0;
var be = 1;
var Go = 2;
var Ke = 3;
var an = 4;
var gr = 5;
var Se = 6;
var Oe = 7;
var Ee = 8;
var _e = 9;
var ve = 10;
function Jo() {
  var e = ["1", "", 0, 0, 0, void 0, "", "", "", void 0, 0];
  return e;
}
function Wo(e, t, n, r) {
  var o3 = /* @__PURE__ */ new Date(), a2 = Math.round(o3.getTime() / 1e3), u2;
  e ? (u2 = e.split("."), u2.unshift("0")) : u2 = ["1", t, a2, r, a2, "", n], (!u2[Se] || u2[Se] === "undefined") && (u2[Se] = te()), (!u2[Oe] || u2[Oe] === "undefined") && (u2[Oe] = ""), (!u2[Ee] || u2[Ee] === "undefined") && (u2[Ee] = ""), (!u2[_e] || u2[_e] === "undefined") && (u2[_e] = ""), (!u2[ve] || u2[ve] === "undefined") && (u2[ve] = 0);
  var c2 = function(l2, v2) {
    var m = parseInt(l2);
    return isNaN(m) ? v2 : m;
  }, f2 = function(l2) {
    return l2 ? c2(l2, void 0) : void 0;
  }, s2 = [u2[pr], u2[be], c2(u2[Go], a2), c2(u2[Ke], r), c2(u2[an], a2), f2(u2[gr]), u2[Se], u2[Oe], u2[Ee], f2(u2[_e]), c2(u2[ve], 0)];
  return s2;
}
function Xo(e, t) {
  var n;
  return e[be] ? n = e[be] : t ? (n = "", e[be] = n) : (n = te(), e[be] = n), n;
}
function Qe(e, t) {
  t === void 0 && (t = { memorizedVisitCount: 1 });
  var n = t.memorizedVisitCount;
  rn(e) ? (e[Oe] = e[Se], e[gr] = e[an], e[Ke]++) : e[Ke] = n;
  var r = te();
  return e[Se] = r, e[ve] = 0, e[Ee] = "", e[_e] = void 0, r;
}
function Qt(e) {
  e[an] = Math.round((/* @__PURE__ */ new Date()).getTime() / 1e3);
}
function Yo(e, t) {
  if (e[ve] === 0) {
    var n = t.build();
    e[Ee] = n.eid;
    var r = n.dtm || n.ttm;
    e[_e] = r ? parseInt(r) : void 0;
  }
}
function Qo(e) {
  e[ve] += 1;
}
function Zo(e, t) {
  var n = W([], e, true);
  return t && (n[be] = "", n[Oe] = ""), n.shift(), n.join(".");
}
function fr(e, t, n) {
  var r = e[_e], o3 = { userId: n ? "00000000-0000-0000-0000-000000000000" : e[be], sessionId: e[Se], eventIndex: e[ve], sessionIndex: e[Ke], previousSessionId: n ? null : e[Oe] || null, storageMechanism: t == "localStorage" ? "LOCAL_STORAGE" : "COOKIE_1", firstEventId: e[Ee] || null, firstEventTimestamp: r ? new Date(r).toISOString() : null };
  return o3;
}
function Zt(e) {
  return e[Se];
}
function $o(e) {
  return e[be];
}
function $t(e) {
  return e[Ke];
}
function rn(e) {
  return e[pr] === "0";
}
function dr(e) {
  return e[ve];
}
var Ko = "iglu:com.snowplowanalytics.snowplow/web_page/jsonschema/1-0-0";
var ei = "iglu:com.snowplowanalytics.snowplow/browser_context/jsonschema/2-0-0";
var ti = "iglu:com.snowplowanalytics.snowplow/client_session/jsonschema/1-0-2";
var ni = "iglu:com.snowplowanalytics.snowplow/application/jsonschema/1-0-0";
function ri() {
  return "ResizeObserver" in window;
}
var vr = false;
var Kt = null;
function oi() {
  if (!vr && !(!document || !document.body || !document.documentElement)) {
    vr = true;
    var e = new ResizeObserver(function() {
      Kt || (Kt = requestAnimationFrame(function() {
        Kt = null, At = on();
      }));
    });
    e.observe(document.body), e.observe(document.documentElement);
  }
}
var At;
var et = "x";
function en() {
  return ri() ? (At || (At = on()), oi(), At) : on();
}
function on() {
  return { viewport: tn(ii()), documentSize: tn(ai()), resolution: tn(ui()), colorDepth: screen.colorDepth, devicePixelRatio: window.devicePixelRatio, cookiesEnabled: window.navigator.cookieEnabled, online: window.navigator.onLine, browserLanguage: window.navigator.language || window.navigator.userLanguage, documentLanguage: document.documentElement.lang, webdriver: window.navigator.webdriver, deviceMemory: window.navigator.deviceMemory, hardwareConcurrency: window.navigator.hardwareConcurrency };
}
function ii() {
  var e, t;
  if ("innerWidth" in window) e = window.innerWidth, t = window.innerHeight;
  else {
    var n = document.documentElement || document.body;
    e = n.clientWidth, t = n.clientHeight;
  }
  return Math.max(0, e) + et + Math.max(0, t);
}
function ai() {
  var e = document.documentElement, t = document.body, n = t ? Math.max(t.offsetHeight, t.scrollHeight) : 0, r = Math.max(e.clientWidth, e.offsetWidth, e.scrollWidth), o3 = Math.max(e.clientHeight, e.offsetHeight, e.scrollHeight, n);
  return isNaN(r) || isNaN(o3) ? "" : r + et + o3;
}
function ui() {
  return screen.width + et + screen.height;
}
function tn(e) {
  return e && e.split(et).map(function(t) {
    return Math.floor(Number(t));
  }).join(et);
}
function si(e) {
  var t, n, r, o3 = true, a2 = 10, u2 = 0.05;
  function c2() {
    var v2;
    return n && (!r || r > /* @__PURE__ */ new Date()) && (v2 = n[0]) !== null && v2 !== void 0 ? v2 : xe(e);
  }
  function f2(v2, m, y, w, g2, P2) {
    return n = [v2, m, y, w, g2, P2], o3 = false, t === void 0 && (t = setTimeout(function() {
      t = void 0, l2();
    }, a2)), r = new Date(Date.now() + Math.min(u2, m != null ? m : u2) * 1e3), true;
  }
  function s2(v2, m, y, w) {
    n = void 0, o3 = true, t !== void 0 && (clearTimeout(t), t = void 0), kt(e, v2, m, y, w);
  }
  function l2() {
    if (t !== void 0 && (clearTimeout(t), t = void 0), !o3 && (o3 = true, n !== void 0)) {
      var v2 = n[0], m = n[1], y = n[2], w = n[3], g2 = n[4], P2 = n[5];
      xe(e, v2, m, y, w, g2, P2);
    }
  }
  return { getValue: c2, setValue: f2, deleteValue: s2, flush: l2 };
}
function ci() {
  var e = {};
  function t(c2) {
    return e[c2] || (e[c2] = si(c2)), e[c2];
  }
  function n(c2) {
    return t(c2).getValue();
  }
  function r(c2, f2, s2, l2, v2, m, y) {
    return t(c2).setValue(f2, s2, l2, v2, m, y);
  }
  function o3(c2, f2, s2, l2, v2) {
    t(c2).deleteValue(f2, s2, l2, v2);
  }
  function a2() {
    e = {};
  }
  function u2() {
    for (var c2 = 0, f2 = Object.values(e); c2 < f2.length; c2++) {
      var s2 = f2[c2];
      s2.flush();
    }
  }
  return { getCookie: n, setCookie: r, deleteCookie: o3, clearCache: a2, flush: u2 };
}
var li = ci();
var fi = { getCookie: xe, setCookie: function(e, t, n, r, o3, a2, u2) {
  return xe(e, t, n, r, o3, a2, u2), document.cookie.indexOf("".concat(e, "=")) !== -1;
}, deleteCookie: kt, flush: function() {
} };
function di(e, t, n, r, o3, a2) {
  a2 === void 0 && (a2 = {});
  var u2 = [], c2 = function(l2, v2, m, y, w, g2) {
    var P2, q, Q, S2, I2, p2, T, H, D, X, ne, ae, ue, F2, z, me, pe, se, Ie, ce;
    g2.eventMethod = (P2 = g2.eventMethod) !== null && P2 !== void 0 ? P2 : "post";
    var C2 = function(i2) {
      var d2;
      return (d2 = i2.stateStorageStrategy) !== null && d2 !== void 0 ? d2 : "cookieAndLocalStorage";
    }, R = function(i2) {
      var d2;
      return typeof i2.anonymousTracking == "boolean" ? false : ((d2 = i2.anonymousTracking) === null || d2 === void 0 ? void 0 : d2.withSessionTracking) === true;
    }, Z = function(i2) {
      var d2;
      return typeof i2.anonymousTracking == "boolean" ? false : ((d2 = i2.anonymousTracking) === null || d2 === void 0 ? void 0 : d2.withServerAnonymisation) === true;
    }, Te = function(i2) {
      return !!i2.anonymousTracking;
    }, De = (Q = (q = g2 == null ? void 0 : g2.contexts) === null || q === void 0 ? void 0 : q.browser) !== null && Q !== void 0 ? Q : false, tt = (I2 = (S2 = g2 == null ? void 0 : g2.contexts) === null || S2 === void 0 ? void 0 : S2.webPage) !== null && I2 !== void 0 ? I2 : true, nt = function(i2) {
      return typeof i2 == "boolean" ? { useExtendedCrossDomainLinker: i2 } : { useExtendedCrossDomainLinker: true, collectCrossDomainAttributes: i2 };
    }, $ = g2.synchronousCookieWrite ? fi : li;
    u2.push(Fr()), tt && u2.push(jr()), De && u2.push(Vr()), u2.push.apply(u2, (p2 = g2.plugins) !== null && p2 !== void 0 ? p2 : []);
    var B = Wn({ base64: (T = g2.encodeBase64) !== null && T !== void 0 ? T : g2.eventMethod !== "post", corePlugins: u2, callback: _r }), Ot = document.characterSet || document.charset, le = lr(window.location.hostname, window.location.href, Yt()), rt = cr(le[0]), b = le[1], x = le[2], k2, O = (H = g2.platform) !== null && H !== void 0 ? H : "web", G = (D = g2.appId) !== null && D !== void 0 ? D : "", U = g2.appVersion, M2, j = document.title, re, Ue = false, oe = (X = g2.resetActivityTrackingOnPageView) !== null && X !== void 0 ? X : true, un, sn, br = (ne = g2.cookieName) !== null && ne !== void 0 ? ne : "_sp_", Pe = (ae = g2.cookieDomain) !== null && ae !== void 0 ? ae : void 0, Sr = (ue = g2.discoverRootDomain) !== null && ue !== void 0 ? ue : Pe === void 0, Me = "/", ot = (F2 = g2.cookieSameSite) !== null && F2 !== void 0 ? F2 : "Lax", it = (z = g2.cookieSecure) !== null && z !== void 0 ? z : true, cn = window.navigator.doNotTrack || window.navigator.msDoNotTrack || window.doNotTrack, ln = typeof g2.respectDoNotTrack != "undefined" ? g2.respectDoNotTrack && (cn === "yes" || cn === "1") : false, Et, fn = (me = g2.cookieLifetime) !== null && me !== void 0 ? me : 63072e3, dn = (pe = g2.sessionCookieTimeout) !== null && pe !== void 0 ? pe : 1800, Ce = R(g2), _t = Z(g2), K = Te(g2), E2 = C2(g2), at, Rt = (/* @__PURE__ */ new Date()).getTime(), ut, st, ct, lt, vn, ft, ee, ie = 1, ge, he = qo(V2({ trackerId: l2, endpoint: Pn(y), serverAnonymization: _t, useLocalStorage: E2 == "localStorage" || E2 == "cookieAndLocalStorage" }, g2), w), Dt = false, je = (se = g2.preservePageViewIdForUrl) !== null && se !== void 0 ? se : false, Ut = void 0, J = { enabled: false, installed: false, configurations: {} }, xr = (ce = (Ie = g2.contexts) === null || Ie === void 0 ? void 0 : Ie.session) !== null && ce !== void 0 ? ce : false, dt, vt = g2.onSessionUpdateCallback, jt = false, mn = nt(g2.useExtendedCrossDomainLinker || false), Ir = mn.useExtendedCrossDomainLinker, Tr = mn.collectCrossDomainAttributes;
    Sr && !Pe && (Pe = Bo(ot, it));
    var mt = en(), Pr = mt.browserLanguage, Cr = mt.resolution, Ar = mt.colorDepth, kr = mt.cookiesEnabled, pn = No();
    B.setTrackerVersion(m), B.setTrackerNamespace(v2), B.setAppId(G), B.setPlatform(O), B.addPayloadPair("cookie", kr ? "1" : "0"), B.addPayloadPair("cs", Ot), B.addPayloadPair("lang", Pr), B.addPayloadPair("res", Cr), B.addPayloadPair("cd", Ar), pn && B.addPayloadPair("tz", pn), U && B.addPlugin({ plugin: { contexts: function() {
      return [{ schema: ni, data: { version: U } }];
    } } }), yn(), Tn(), g2.crossDomainLinker && gn(g2.crossDomainLinker);
    function Ae() {
      le = lr(window.location.hostname, window.location.href, Yt()), le[1] !== b && (x = Yt(b)), rt = cr(le[0]), b = le[1];
    }
    function Or(i2) {
      var d2 = "_sp";
      return function(h2) {
        var A = h2.currentTarget, _ = Vo(i2, Tr, { domainUserId: ft, userId: ge || void 0, sessionId: ee, sourceId: G, sourcePlatform: O, event: h2 });
        A != null && A.href && (A.href = zo(A.href, d2, _));
      };
    }
    function gn(i2) {
      for (var d2 = Or(Ir), h2 = 0; h2 < document.links.length; h2++) {
        var A = document.links[h2];
        !A.spDecorationEnabled && i2(A) && (A.addEventListener("click", d2, true), A.addEventListener("mousedown", d2, true), A.spDecorationEnabled = true);
      }
    }
    function ke(i2) {
      var d2;
      return un && (d2 = new RegExp("#.*"), i2 = i2.replace(d2, "")), sn && (d2 = new RegExp("[{}]", "g"), i2 = i2.replace(d2, "")), i2;
    }
    function hn(i2) {
      var d2 = new RegExp("^([a-z]+):"), h2 = d2.exec(i2);
      return h2 ? h2[1] : null;
    }
    function Er(i2, d2) {
      var h2 = hn(d2), A;
      return h2 ? d2 : d2.slice(0, 1) === "/" ? hn(i2) + "://" + nn(i2) + d2 : (i2 = ke(i2), (A = i2.indexOf("?")) >= 0 && (i2 = i2.slice(0, A)), (A = i2.lastIndexOf("/")) !== i2.length - 1 && (i2 = i2.slice(0, A + 1)), i2 + d2);
    }
    function _r(i2) {
      ln || dt || he.enqueueRequest(i2.build());
    }
    function Ve(i2) {
      return br + i2 + "." + vn;
    }
    function pt(i2) {
      var d2 = Ve(i2);
      if (E2 == "localStorage") return Ro(d2);
      if (E2 == "cookie" || E2 == "cookieAndLocalStorage") return $.getCookie(d2);
    }
    function yn() {
      Ae(), vn = (0, mr.default)((Pe || rt) + (Me || "/")).slice(0, 4);
    }
    function qe() {
      var i2 = /* @__PURE__ */ new Date();
      at = i2.getTime();
    }
    function Rr() {
      Dr(), qe();
    }
    function wn() {
      var i2 = document.documentElement;
      return i2 ? [i2.scrollLeft || window.pageXOffset, i2.scrollTop || window.pageYOffset] : [0, 0];
    }
    function bn() {
      var i2 = wn(), d2 = i2[0];
      ut = d2, st = d2;
      var h2 = i2[1];
      ct = h2, lt = h2;
    }
    function Dr() {
      var i2 = wn(), d2 = i2[0];
      d2 < ut ? ut = d2 : d2 > st && (st = d2);
      var h2 = i2[1];
      h2 < ct ? ct = h2 : h2 > lt && (lt = h2);
    }
    function gt(i2) {
      return Math.round(i2);
    }
    function ht() {
      var i2 = Ve("ses"), d2 = "*";
      return Sn(i2, d2, dn);
    }
    function Vt(i2) {
      var d2 = Ve("id"), h2 = Zo(i2, K);
      return Sn(d2, h2, fn);
    }
    function Sn(i2, d2, h2) {
      return K && !Ce ? false : E2 == "localStorage" ? Do(i2, d2, h2) : E2 == "cookie" || E2 == "cookieAndLocalStorage" ? $.setCookie(i2, d2, h2, Me, Pe, ot, it) : false;
    }
    function xn(i2) {
      var d2 = Ve("id"), h2 = Ve("ses");
      ir(d2), ir(h2), $.deleteCookie(d2, Me, Pe, ot, it), $.deleteCookie(h2, Me, Pe, ot, it), i2 != null && i2.preserveSession || (ee = te(), ie = 1), i2 != null && i2.preserveUser || (ft = K ? "" : te(), ge = null);
    }
    function In(i2) {
      i2 && i2.stateStorageStrategy && (g2.stateStorageStrategy = i2.stateStorageStrategy, E2 = C2(g2)), K = Te(g2), Ce = R(g2), _t = Z(g2), he.setUseLocalStorage(E2 == "localStorage" || E2 == "cookieAndLocalStorage"), he.setAnonymousTracking(_t);
    }
    function Tn() {
      if (!(K && !Ce)) {
        var i2 = E2 != "none" && !!pt("ses"), d2 = He();
        ft = Xo(d2, K), i2 ? ee = Zt(d2) : ee = Qe(d2), ie = $t(d2), E2 != "none" && (ht(), Qt(d2), Vt(d2), dr(d2) || $.flush());
      }
    }
    function He() {
      if (E2 == "none") return Jo();
      var i2 = pt("id") || void 0;
      return Wo(i2, ft, ee, ie);
    }
    function Pn(i2) {
      return i2.indexOf("http") === 0 ? i2 : (document.location.protocol === "https:" ? "https" : "http") + "://" + i2;
    }
    function Cn() {
      (!Dt || w.pageViewId == null) && (w.pageViewId = te(), w.pageViewUrl = M2 || b);
    }
    function Ge() {
      return Ur() && (w.pageViewId = te(), w.pageViewUrl = M2 || b), w.pageViewId;
    }
    function Ur() {
      if (w.pageViewId == null) return true;
      if (Dt || !je) return false;
      if (w.pageViewUrl === void 0) return true;
      var i2 = M2 || b;
      if (je === true || je == "full" || !("URL" in window)) return w.pageViewUrl != i2;
      var d2 = new URL(i2), h2 = new URL(w.pageViewUrl);
      return je == "pathname" ? d2.pathname != h2.pathname : je == "pathnameAndSearch" ? d2.pathname != h2.pathname || d2.search != h2.search : false;
    }
    function An() {
      if (E2 === "none" || K || !tt) return null;
      var i2 = "_sp_tab_id", d2 = ar(i2);
      return d2 || (Uo(i2, te()), d2 = ar(i2)), d2 || null;
    }
    function jr() {
      return { contexts: function() {
        return [{ schema: Ko, data: { id: Ge() } }];
      } };
    }
    function Vr() {
      return { contexts: function() {
        return [{ schema: ei, data: V2(V2({}, en()), { tabId: An() }) }];
      } };
    }
    function Fr() {
      var i2 = function(h2) {
        return K ? null : h2;
      }, d2 = function(h2) {
        return Ce ? h2 : i2(h2);
      };
      return { beforeTrack: function(h2) {
        var A = pt("ses"), _ = He(), ye = dr(_) === 0;
        if (Et ? dt = !!$.getCookie(Et) : dt = false, ln || dt) {
          xn();
          return;
        }
        rn(_) ? (!A && E2 != "none" ? ee = Qe(_) : ee = Zt(_), ie = $t(_)) : (/* @__PURE__ */ new Date()).getTime() - Rt > dn * 1e3 && (ie++, ee = Qe(_, { memorizedVisitCount: ie })), Qt(_), Yo(_, h2), Qo(_);
        var Y = en(), Fe = Y.viewport, Je = Y.documentSize;
        h2.add("vp", Fe), h2.add("ds", Je), h2.add("vid", d2(ie)), h2.add("sid", d2(ee)), h2.add("duid", i2($o(_))), h2.add("uid", i2(ge)), Ae(), h2.add("refr", ke(k2 || x)), h2.add("url", ke(M2 || b));
        var We = fr(_, E2, K);
        if (xr && (!K || Ce) && Nr(h2, We), E2 != "none") {
          Vt(_);
          var Nt = ht();
          (!A || ye) && Nt && vt && !jt && ($.flush(), vt(We), jt = false);
        }
        Rt = (/* @__PURE__ */ new Date()).getTime();
      } };
    }
    function Nr(i2, d2) {
      var h2 = { schema: ti, data: d2 };
      i2.addContextEntity(h2);
    }
    function zr() {
      var i2 = He();
      if (rn(i2) ? (E2 != "none" ? ee = Qe(i2) : ee = Zt(i2), ie = $t(i2)) : (ie++, ee = Qe(i2, { memorizedVisitCount: ie })), Qt(i2), E2 != "none") {
        var d2 = fr(i2, E2, K);
        Vt(i2);
        var h2 = ht();
        $.flush(), h2 && vt && (jt = true, vt(d2));
      }
      Rt = (/* @__PURE__ */ new Date()).getTime();
    }
    function Ft(i2, d2) {
      return (i2 || []).concat(d2 ? d2() : []);
    }
    function Br(i2) {
      var d2 = i2.title, h2 = i2.context, A = i2.timestamp, _ = i2.contextCallback;
      Ae(), Ut && Ut == Ge() && Cn(), Ut = Ge(), j = document.title, d2 ? (re = d2, Ue = true) : Ue && (re = null);
      var ye = sr(re || j);
      B.track(Yn({ pageUrl: ke(M2 || b), pageTitle: ye, referrer: ke(k2 || x) }), Ft(h2, _), A);
      var Y = /* @__PURE__ */ new Date(), Fe = false;
      if (J.enabled && !J.installed) {
        J.installed = true, Fe = true;
        var Je = { update: function() {
          if (typeof window != "undefined" && typeof window.addEventListener == "function") {
            var Ne = false, yt = Object.defineProperty({}, "passive", { get: function() {
              Ne = true;
            }, set: function() {
            } }), _n = function() {
            };
            window.addEventListener("testPassiveEventSupport", _n, yt), window.removeEventListener("testPassiveEventSupport", _n, yt), Je.hasSupport = Ne;
          }
        } };
        Je.update();
        var We = "onwheel" in document.createElement("div") ? "wheel" : document.onmousewheel !== void 0 ? "mousewheel" : "DOMMouseScroll";
        Object.prototype.hasOwnProperty.call(Je, "hasSupport") ? Le(document, We, qe, { passive: true }) : Le(document, We, qe), bn();
        var Nt = ["click", "mouseup", "mousedown", "mousemove", "keypress", "keydown", "keyup", "touchend", "touchstart"], Hr = ["resize", "focus", "blur"], zt = function(Gr, Ne) {
          return Ne === void 0 && (Ne = qe), function(yt) {
            return Le(document, yt, Ne);
          };
        };
        Nt.forEach(zt(document)), Hr.forEach(zt(window)), zt(window, Rr)("scroll");
      }
      if (J.enabled && (oe || Fe)) {
        at = Y.getTime();
        var En = void 0;
        for (En in J.configurations) {
          var Bt = J.configurations[En];
          Bt && (window.clearInterval(Bt.activityInterval), Lr(Bt, h2, _));
        }
      }
    }
    function Lr(i2, d2, h2) {
      var A = function(Y, Fe) {
        Ae(), Y({ context: Fe, pageViewId: Ge(), minXOffset: ut, minYOffset: ct, maxXOffset: st, maxYOffset: lt }), bn();
      }, _ = function() {
        var Y = /* @__PURE__ */ new Date();
        at + i2.configMinimumVisitLength > Y.getTime() && A(i2.callback, Ft(d2, h2)), i2.activityInterval = window.setInterval(ye, i2.configHeartBeatTimer);
      }, ye = function() {
        var Y = /* @__PURE__ */ new Date();
        at + i2.configHeartBeatTimer > Y.getTime() && A(i2.callback, Ft(d2, h2));
      };
      i2.configMinimumVisitLength === 0 ? i2.activityInterval = window.setInterval(ye, i2.configHeartBeatTimer) : i2.activityInterval = window.setTimeout(_, i2.configMinimumVisitLength);
    }
    function kn(i2) {
      var d2 = i2.minimumVisitLength, h2 = i2.heartbeatDelay, A = i2.callback;
      if (ur(d2) && ur(h2)) return { configMinimumVisitLength: d2 * 1e3, configHeartBeatTimer: h2 * 1e3, callback: A };
      L.error("Activity tracking minimumVisitLength & heartbeatDelay must be integers");
    }
    function Mr(i2) {
      var d2 = i2.context, h2 = i2.minXOffset, A = i2.minYOffset, _ = i2.maxXOffset, ye = i2.maxYOffset, Y = document.title;
      Y !== j && (j = Y, re = void 0), B.track(Qn({ pageUrl: ke(M2 || b), pageTitle: sr(re || j), referrer: ke(k2 || x), minXOffset: gt(h2), maxXOffset: gt(_), minYOffset: gt(A), maxYOffset: gt(ye) }), d2);
    }
    function On(i2) {
      var d2 = J.configurations[i2];
      (d2 == null ? void 0 : d2.configMinimumVisitLength) === 0 ? window.clearTimeout(d2 == null ? void 0 : d2.activityInterval) : window.clearInterval(d2 == null ? void 0 : d2.activityInterval), J.configurations[i2] = void 0;
    }
    var qr = { getDomainSessionIndex: function() {
      return ie;
    }, getPageViewId: Ge, getTabId: An, newSession: zr, getCookieName: function(i2) {
      return Ve(i2);
    }, getUserId: function() {
      return ge;
    }, getDomainUserId: function() {
      return He()[1];
    }, getDomainUserInfo: function() {
      return He();
    }, setReferrerUrl: function(i2) {
      k2 = i2;
    }, setCustomUrl: function(i2) {
      Ae(), M2 = Er(b, i2);
    }, setDocumentTitle: function(i2) {
      j = document.title, re = i2, Ue = false;
    }, discardHashTag: function(i2) {
      un = i2;
    }, discardBrace: function(i2) {
      sn = i2;
    }, setCookiePath: function(i2) {
      Me = i2, yn();
    }, setVisitorCookieTimeout: function(i2) {
      fn = i2;
    }, crossDomainLinker: function(i2) {
      gn(i2);
    }, enableActivityTracking: function(i2) {
      J.configurations.pagePing || (J.enabled = true, J.configurations.pagePing = kn(V2(V2({}, i2), { callback: Mr })));
    }, enableActivityTrackingCallback: function(i2) {
      J.configurations.callback || (J.enabled = true, J.configurations.callback = kn(i2));
    }, disableActivityTracking: function() {
      On("pagePing");
    }, disableActivityTrackingCallback: function() {
      On("callback");
    }, updatePageActivity: function() {
      qe();
    }, setOptOutCookie: function(i2) {
      Et = i2;
    }, setUserId: function(i2) {
      ge = i2;
    }, setUserIdFromLocation: function(i2) {
      Ae(), ge = $e(i2, b);
    }, setUserIdFromReferrer: function(i2) {
      Ae(), ge = $e(i2, x);
    }, setUserIdFromCookie: function(i2) {
      ge = $.getCookie(i2);
    }, setCollectorUrl: function(i2) {
      he.setCollectorUrl(Pn(i2));
    }, setBufferSize: function(i2) {
      he.setBufferSize(i2);
    }, flushBuffer: function(i2) {
      i2 === void 0 && (i2 = {}), he.executeQueue(), i2.newBufferSize && he.setBufferSize(i2.newBufferSize);
    }, trackPageView: function(i2) {
      i2 === void 0 && (i2 = {}), Br(i2);
    }, preservePageViewId: function() {
      Dt = true;
    }, preservePageViewIdForUrl: function(i2) {
      je = i2;
    }, disableAnonymousTracking: function(i2) {
      var d2 = (i2 == null ? void 0 : i2.stateStorageStrategy) && i2.stateStorageStrategy !== E2 && (!K || Ce) && pt("ses");
      g2.anonymousTracking = false, In(i2), d2 && ht(), Tn(), he.executeQueue();
    }, enableAnonymousTracking: function(i2) {
      var d2;
      g2.anonymousTracking = (d2 = i2 && (i2 == null ? void 0 : i2.options)) !== null && d2 !== void 0 ? d2 : true, In(i2), Ce || Cn();
    }, clearUserData: xn };
    return V2(V2({}, qr), { id: l2, namespace: v2, core: B, sharedState: w });
  }, f2 = c2(e, t, n, r, o3, a2), s2 = V2(V2({}, f2), { addPlugin: function(l2) {
    var v2, m;
    s2.core.addPlugin(l2), (m = (v2 = l2.plugin).activateBrowserPlugin) === null || m === void 0 || m.call(v2, s2);
  } });
  return u2.forEach(function(l2) {
    var v2;
    (v2 = l2.activateBrowserPlugin) === null || v2 === void 0 || v2.call(l2, s2);
  }), s2;
}
var Ze = {};
function Re(e, t) {
  try {
    vi(e != null ? e : mi()).forEach(t);
  } catch (n) {
    L.error("Function failed", n);
  }
}
function hr(e, t, n, r, o3, a2) {
  return Ze.hasOwnProperty(e) ? null : (Ze[e] = di(e, t, n, r, o3, a2), Ze[e]);
}
function vi(e) {
  return pi(e, Ze);
}
function mi() {
  return Object.keys(Ze);
}
function pi(e, t) {
  for (var n = [], r = 0, o3 = e; r < o3.length; r++) {
    var a2 = o3[r];
    t.hasOwnProperty(a2) ? n.push(t[a2]) : L.warn(a2 + " not configured");
  }
  return n;
}
var gi = /* @__PURE__ */ function() {
  function e() {
    this.bufferFlushers = [], this.hasLoaded = false, this.registeredOnLoadHandlers = [];
  }
  return e;
}();
function yr() {
  var e = new gi(), t = document, n = window;
  function r() {
    t.visibilityState == "hidden" && e.bufferFlushers.forEach(function(c2) {
      c2(false);
    });
  }
  function o3() {
    e.bufferFlushers.forEach(function(c2) {
      c2(false);
    });
  }
  function a2() {
    var c2;
    if (!e.hasLoaded) for (e.hasLoaded = true, c2 = 0; c2 < e.registeredOnLoadHandlers.length; c2++) e.registeredOnLoadHandlers[c2]();
    return true;
  }
  function u2() {
    t.addEventListener ? t.addEventListener("DOMContentLoaded", function c2() {
      t.removeEventListener("DOMContentLoaded", c2, false), a2();
    }) : t.attachEvent && t.attachEvent("onreadystatechange", function c2() {
      t.readyState === "complete" && (t.detachEvent("onreadystatechange", c2), a2());
    }), Le(n, "load", a2, false);
  }
  return t.visibilityState && Le(t, "visibilitychange", r, false), Le(n, "beforeunload", o3, false), document.readyState === "loading" ? u2() : a2(), e;
}
function hi(e, t) {
  Re(t, function(n) {
    n.setUserId(e);
  });
}
function yi(e, t) {
  Re(t, function(n) {
    n.trackPageView(e);
  });
}
function wi(e, t) {
  Re(t, function(n) {
    n.core.track(Zn(e), e.context, e.timestamp);
  });
}
function bi(e, t) {
  Re(t, function(n) {
    n.core.track(Xn({ event: e.event }), e.context, e.timestamp);
  });
}
function Si(e) {
  Re(e, function(t) {
    t.preservePageViewId();
  });
}
function xi(e, t) {
  Re(t, function(n) {
    n.addPlugin(e);
  });
}
var wr = typeof window != "undefined" ? yr() : void 0;
function Ii(e, t, n) {
  if (wr) return hr(e, e, "js-".concat(Kn), t, wr, n);
}

// src/utils/tracking/snowplow/super-snowplow-tracker.ts
var debug3 = debugFactory("app:snowplow");
var SnowplowTracker = class extends NrkBaseTracker {
  constructor() {
    super(snowplow_bundle_exports, {
      trackerId: "nrksuper",
      collectorUrl: "https://no-nrk-prod1.mini.snplow.net",
      appId: "no.nrk.tv.super",
      serviceId: ServiceID.Nrksuper,
      plugins: [
        new F(),
        new a()
      ]
    });
  }
  trackPageView(contentEntity) {
    super.trackPageView(contentEntity);
    debug3("Tracked page view");
  }
  // Docs impression tracking:
  // https://github.com/nrkno/snowplow-tooling/blob/main/tracking-docs/eksponeringer.md#tv
  sendImpressionsEvent(snowplowPlugsAnalytics, trackingContext) {
    const { pageId, kind, source, recommendationId } = trackingContext;
    if (!pageId) {
      debug3("Not sending impression event because is missing: ", { pageId });
      return;
    }
    this.trackSchemaEvent(
      EventSchema.ImpressionEvent,
      {
        kind: ImpressionEventKind.Impression
      },
      {
        [EntitySchema.Plug]: snowplowPlugsAnalytics.map(
          (snowplugAnalytics) => getSnowplowPlugEntity(
            snowplugAnalytics,
            snowplugAnalytics.recommendationId ?? recommendationId
          )
        ),
        [EntitySchema.Content]: { id: pageId, kind, source }
      }
    );
    debug3(
      `Sent impressions event for ${snowplowPlugsAnalytics.length} plugs: `,
      snowplowPlugsAnalytics.map((impression) => impression.content.id).toString(),
      snowplowPlugsAnalytics
    );
  }
  sendClickEvent(snowplowPlugAnalytics, trackingContext) {
    const { pageId, recommendationId } = trackingContext;
    if (!pageId) {
      debug3("Not sending impression event because is missing: ", { pageId });
      return;
    }
    this.trackSchemaEvent(
      EventSchema.ClickEvent,
      {
        kind: ClickEventKind.Content
      },
      {
        [EntitySchema.Plug]: getSnowplowPlugEntity(
          snowplowPlugAnalytics,
          snowplowPlugAnalytics.recommendationId ?? recommendationId
        ),
        [EntitySchema.Content]: { id: pageId }
      }
    );
    debug3("Sent click event for plug: ", snowplowPlugAnalytics);
  }
};
function getSnowplowPlugEntity(snowplowPlugAnalytics, recommendationId) {
  return {
    ...snowplowPlugAnalytics,
    recommendationId
  };
}
window.snowplowTracker = new SnowplowTracker();
/*! Bundled license information:

@nrk/snowplow-web/snowplow-bundle.js:
  (*! Bundled license information:
  
  @snowplow/tracker-core/dist/index.module.js:
    (*!
     * Core functionality for Snowplow JavaScript trackers v4.6.3 (http://bit.ly/sp-js)
     * Copyright 2022 Snowplow Analytics Ltd, 2010 Anthon Pang
     * Licensed under BSD-3-Clause
     *)
  
  @snowplow/browser-tracker-core/dist/index.module.js:
    (*!
     * Core functionality for Snowplow Browser trackers v4.6.3 (http://bit.ly/sp-js)
     * Copyright 2022 Snowplow Analytics Ltd, 2010 Anthon Pang
     * Licensed under BSD-3-Clause
     *)
  
  @snowplow/browser-tracker/dist/index.module.js:
    (*!
     * Browser tracker for Snowplow v4.6.3 (http://bit.ly/sp-js)
     * Copyright 2022 Snowplow Analytics Ltd, 2010 Anthon Pang
     * Licensed under BSD-3-Clause
     *)
  *)
*/
